//Версия для МК 1.5
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>
#include <EEPROM.h>
#include "RI_logo_image_120x120.h"

// ==================== ПИНЫ ====================
// Энкодер
#define ENC_S1 35
#define ENC_S2 32
#define ENC_KEY 34

// TFT экран
#define TFT_CS 5
#define TFT_RST 4
#define TFT_DC 2
#define TFT_SDA 23
#define TFT_SCK 18
#define TFT_LED 12

// Управление
#define PUMP_PIN 25
#define DIR_PIN 26
#define COUNT_PIN 36
#define SPEED_PIN 27
#define SENSOR_VN 39

// ==================== НАСТРОЙКИ ====================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 160

#define ENCODER_SENSITIVITY 3
#define ENCODER_DEBOUNCE_DELAY 5
#define LONG_PRESS_TIME 600

#define VOLTAGE_THRESHOLD 2.0
#define ADC_MAX 4095
#define ADC_VOLTAGE 3.3

#define HV_THRESHOLD 2.0f
#define HV_UPDATE_INTERVAL 200

#define EEPROM_SIZE 128
#define EEPROM_ADDR_EXPOSITION 0
#define EEPROM_ADDR_SPEED 4
#define EEPROM_ADDR_TOTAL_COUNTER 8

#define LOGO_SHOW_TIME 2000
#define USB_POLLING_TIMEOUT 2000
#define BACKGROUND_PROMPT_TIMEOUT 10000  // 10 секунд на вопрос о фоне

// ==================== ФОНОВЫЙ ЗАМЕР ====================
#define BACKGROUND_MEASURE_TIME 300000UL   // 5 минут
#define BACKGROUND_UPDATE_INTERVAL 1000UL  // обновление экрана

// ==================== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ====================
Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RST);

// Состояния
bool pumpState = false;
bool dirState = false;
float expositionTime = 30.0;
int speedPercent = 0;

// Счетчики
int counterValue = 0;
long totalCounterValue = 0;
bool countingActive = false;
unsigned long countingStartTime = 0;
bool lastTriggerState = false;
bool resultShown = false;
unsigned long resultDisplayTime = 0;
int lastDisplayedCounterValue = -1;

// Таймер насоса
unsigned long pumpOnTime = 0;
bool pumpTimerActive = false;
unsigned long lastTimerUpdate = 0;
int lastDisplayedMinutes = -1;
int lastDisplayedSeconds = -1;

// Фоновый замер
bool backgroundMeasureActive = false;
unsigned long backgroundMeasureStartTime = 0;
unsigned long lastBackgroundDisplayUpdate = 0;
long backgroundTotalPulses = 0;
int backgroundPulsesPerMinute = 0;
bool backgroundLastTriggerState = false;
int backgroundSavedValue = 0;
bool backgroundMeasureFromUSB = false; // Флаг что замер запущен с USB

// HV датчик
bool hvState = false;
bool lastHvState = false;
unsigned long lastHvUpdate = 0;
unsigned long lastHvBlinkTime = 0;
bool hvBlinkState = false;
float lastHvVoltage = 0.0f;

// USB опрос
unsigned long lastUsbCommandTime = 0;
bool usbPollingActive = false;

// Меню
int selectedItem = 0;
const int menuItems = 5;

enum SystemMode {
  MODE_LOGO,
  MODE_BACKGROUND_MEASURE,
  MODE_BACKGROUND_DONE,
  MODE_MENU,
  MODE_SET_EXPOSITION,
  MODE_SET_SPEED,
  MODE_BACKGROUND_PROMPT  // Новый режим для вопроса о фоне
};
SystemMode currentMode = MODE_LOGO;

// Кнопка и энкодер
bool lastButtonState = HIGH;
unsigned long buttonPressTime = 0;
bool buttonProcessed = false;
int lastEncState = 0;
int encoderCounter = 0;
unsigned long lastDebounceTime = 0;

bool totalResetRequested = false;
unsigned long totalResetStartTime = 0;
bool needRedrawMenu = true;

// Переменные для отслеживания изменений
float lastExpositionValue = -1;
int lastSpeedValue = -1;
long lastTotalValue = -1;
bool lastPumpStateForRedraw = false;
bool lastDirStateForRedraw = false;

// Массив допустимых значений экспозиции
const float expoValues[] = { 0.5, 1, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120 };
const int expoCount = sizeof(expoValues) / sizeof(expoValues[0]);
int expoIndex = 4;

// ==================== ПРОТОТИПЫ ФУНКЦИЙ ====================
void showLogo();
void saveSettings();
void loadSettings();
void updateHVStatus();
void drawHVIndicator();
void drawUSBIndicator();
void drawMenuTitle();
void updateCounterAndTotalDisplay();
void forceUpdateTotalDisplay();
void setPWMDutyCycle(int percent);
void processCounting();
void readEncoderMenu();
void readButtonMenu();
void readEncoderExposition();
void readButtonExposition();
void readEncoderSpeed();
void readButtonSpeed();
void togglePump();
void toggleDir();
void showMessage(String line1, String line2);
void updatePumpTimerDisplay();
void fullRedraw();
void updateDynamicValuesOnly();
void updateExpositionDisplay();
void updateSpeedDisplay();
void processSerialCommand(String cmd);
void sendPumpTime();
void updateUsbPollingStatus();
int findExpoIndex(float value);

// Фоновый замер
void drawBackgroundPrompt();
void startBackgroundMeasure();
void processBackgroundMeasure();
void drawBackgroundMeasure();
void updateBackgroundDisplay();
void finishBackgroundMeasure();
void drawBackgroundValue();
void waitForButtonPressWithTimeout();
void drawBackgroundHVIndicator();
void readBackgroundDone();
void stopBackgroundMeasure();

// ==================== НАСТРОЙКА ====================
void setup() {
  Serial.begin(38400);
  Serial.println("Device ready");

  EEPROM.begin(EEPROM_SIZE);

  pinMode(ENC_S1, INPUT_PULLUP);
  pinMode(ENC_S2, INPUT_PULLUP);
  pinMode(ENC_KEY, INPUT_PULLUP);
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(DIR_PIN, OUTPUT);
  pinMode(COUNT_PIN, INPUT);
  pinMode(SPEED_PIN, OUTPUT);
  pinMode(SENSOR_VN, INPUT);

  digitalWrite(PUMP_PIN, LOW);
  digitalWrite(DIR_PIN, LOW);
  analogWrite(SPEED_PIN, 0);

  tft.initR(INITR_BLACKTAB);
  tft.setRotation(1);

  pinMode(TFT_LED, OUTPUT);
  digitalWrite(TFT_LED, HIGH);

  loadSettings();

  lastEncState = digitalRead(ENC_S1);

  // Инициализируем переменные для отслеживания
  lastPumpStateForRedraw = pumpState;
  lastDirStateForRedraw = dirState;
  lastExpositionValue = expositionTime;
  lastSpeedValue = speedPercent;
  lastTotalValue = totalCounterValue;

  expoIndex = findExpoIndex(expositionTime);

  // ===== ПОСЛЕДОВАТЕЛЬНОСТЬ ЗАПУСКА =====

  // 1. Показываем логотип
  showLogo();
  delay(LOGO_SHOW_TIME);

  // 2. Показываем вопрос о фоне с таймаутом 10 секунд
  drawBackgroundPrompt();
  currentMode = MODE_BACKGROUND_PROMPT;
  
  // Ждем нажатия кнопки или таймаут
  waitForButtonPressWithTimeout();

  // 3. Переходим в главное меню
  delay(200);
  lastButtonState = digitalRead(ENC_KEY);
  buttonProcessed = true;
  buttonPressTime = 0;
  totalResetRequested = false;

  currentMode = MODE_MENU;
  needRedrawMenu = true;
  fullRedraw();
}

// ===== НОВАЯ ФУНКЦИЯ: ОЖИДАНИЕ КНОПКИ С ТАЙМАУТОМ =====
void waitForButtonPressWithTimeout() {
  bool buttonPressed = false;
  int localSelectedItem = 0;  // 0 = Yes, 1 = No
  unsigned long startTime = millis();
  bool timeoutReached = false;

  while (!buttonPressed) {
    // Проверяем таймаут
    if (millis() - startTime >= BACKGROUND_PROMPT_TIMEOUT) {
      timeoutReached = true;
      buttonPressed = true;
      // При таймауте выбираем NO (пропустить замер)
      localSelectedItem = 1;
      break;
    }

    // Читаем энкодер для выбора Yes/No
    int encState = digitalRead(ENC_S1);

    if (encState != lastEncState && (millis() - lastDebounceTime) > ENCODER_DEBOUNCE_DELAY) {
      lastDebounceTime = millis();
      int encB = digitalRead(ENC_S2);

      if (encB != encState) {
        encoderCounter++;
        if (encoderCounter >= ENCODER_SENSITIVITY) {
          localSelectedItem++;
          if (localSelectedItem > 1) localSelectedItem = 0;
          encoderCounter = 0;
          drawBackgroundPromptWithSelection(localSelectedItem);
        }
      } else {
        encoderCounter--;
        if (encoderCounter <= -ENCODER_SENSITIVITY) {
          localSelectedItem--;
          if (localSelectedItem < 0) localSelectedItem = 1;
          encoderCounter = 0;
          drawBackgroundPromptWithSelection(localSelectedItem);
        }
      }
    }
    lastEncState = encState;

    // Читаем кнопку
    bool currentButtonState = digitalRead(ENC_KEY);

    if (lastButtonState == HIGH && currentButtonState == LOW) {
      buttonPressTime = millis();
    }

    if (currentButtonState == LOW && (millis() - buttonPressTime) >= LONG_PRESS_TIME) {
      buttonPressed = true;

      if (localSelectedItem == 0) {
        // Выбрано YES - запускаем замер
        backgroundMeasureFromUSB = false;
        startBackgroundMeasure();
        // Ждем завершения замера
        while (currentMode == MODE_BACKGROUND_MEASURE) {
          processBackgroundMeasure();
          delay(10);
        }
        // После завершения замера показываем результат и ждем нажатия
        while (currentMode == MODE_BACKGROUND_DONE) {
          readBackgroundDone();
          delay(10);
        }
      } else {
        // Выбрано NO - пропускаем
        backgroundSavedValue = 0;
      }
    }

    lastButtonState = currentButtonState;
    delay(10);
  }
  
  // Если был таймаут и выбрано NO - просто пропускаем
  if (timeoutReached && localSelectedItem == 1) {
    backgroundSavedValue = 0;
  }
}

void drawBackgroundPromptWithSelection(int selected) {
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(8, 20);
  tft.print("BACKGROUND");

  tft.setCursor(8, 32);
  tft.print("RADIATION");

  tft.drawLine(5, 45, SCREEN_WIDTH - 5, 45, ST77XX_CYAN);

  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(4, 58);
  tft.print("Measure the");

  tft.setCursor(4, 70);
  tft.print("background");

  tft.setCursor(4, 82);
  tft.print("radiation value?");

  // Yes / No
  if (selected == 0) {
    tft.fillRect(10, 105, 48, 22, ST77XX_BLUE);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
  } else {
    tft.drawRect(10, 105, 48, 22, ST77XX_BLUE);
    tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
  }
  tft.setCursor(22, 112);
  tft.print("Yes");

  if (selected == 1) {
    tft.fillRect(70, 105, 48, 22, ST77XX_BLUE);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
  } else {
    tft.drawRect(70, 105, 48, 22, ST77XX_BLUE);
    tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
  }
  tft.setCursor(84, 112);
  tft.print("No");

  // Показываем таймаут
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.setCursor(8, 140);
  tft.print("Auto: No in 10s");

  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.setCursor(8, 150);
  tft.print("Rotate: Select");
}

// ==================== ОСНОВНОЙ ЦИКЛ ====================
void loop() {
  // Обработка команд с USB
  if (Serial.available()) {
    String command = Serial.readStringUntil('\n');
    command.trim();
    if (command.length() > 0) {
      lastUsbCommandTime = millis();
      if (!usbPollingActive) {
        usbPollingActive = true;
        updateUsbPollingStatus();
      }
      processSerialCommand(command);
    }
  }

  // Проверка таймаута USB опроса
  if (usbPollingActive && (millis() - lastUsbCommandTime >= USB_POLLING_TIMEOUT)) {
    usbPollingActive = false;
    updateUsbPollingStatus();
  }

  // Обновление статуса HV
  updateHVStatus();

  // Фоновый замер выполняется отдельно от работы насоса
  if (currentMode == MODE_BACKGROUND_MEASURE) {
    processBackgroundMeasure();
  } else if (currentMode == MODE_BACKGROUND_DONE) {
    // Ждем нажатия для перехода в меню (только если замер не с USB)
    if (!backgroundMeasureFromUSB) {
      readBackgroundDone();
    } else {
      // Если замер с USB - сразу переходим в меню
      currentMode = MODE_MENU;
      selectedItem = 0;
      needRedrawMenu = true;
      backgroundMeasureFromUSB = false;
    }
  } else if (currentMode == MODE_BACKGROUND_PROMPT) {
    // Этот режим обрабатывается в setup, но на всякий случай
    currentMode = MODE_MENU;
    needRedrawMenu = true;
  } else {
    // Обработка счета импульсов насоса
    if (pumpState) {
      processCounting();
    } else {
      if (countingActive) {
        countingActive = false;
        counterValue = 0;
        resultShown = false;
        lastDisplayedCounterValue = -1;
        updateCounterAndTotalDisplay();
      }
    }

    // Скрытие результата через 3 секунды
    if (resultShown && (millis() - resultDisplayTime >= 3000)) {
      resultShown = false;
      lastDisplayedCounterValue = -1;
      updateCounterAndTotalDisplay();
    }
  }

  // Обработка ввода в зависимости от режима
  if (currentMode == MODE_MENU) {
    readEncoderMenu();
    readButtonMenu();
  } else if (currentMode == MODE_SET_EXPOSITION) {
    readEncoderExposition();
    readButtonExposition();
  } else if (currentMode == MODE_SET_SPEED) {
    readEncoderSpeed();
    readButtonSpeed();
  }

  // Обновление только динамических значений для меню
  if (currentMode == MODE_MENU) {
    updateDynamicValuesOnly();
  }

  // Полная перерисовка только когда действительно нужно
  if (needRedrawMenu) {
    needRedrawMenu = false;
    fullRedraw();
  }

  delay(10);
}

// ==================== USB КОМАНДНЫЙ ПРОТОКОЛ ====================
void processSerialCommand(String cmd) {
  // Убираем эхо команд! Не отправляем CMD обратно.
  
  // ===== КОМАНДА ПОЛУЧЕНИЯ ВСЕХ ДАННЫХ =====
  // Формат: pumpState,dirState,expositionTime,speedPercent,counterValue,totalCounterValue,hvState,pumpTime,hvVoltage,backgroundValue
  if (cmd == "GET:FULLSTATUS") {
    Serial.print("FULLSTATUS:");
    Serial.print(pumpState ? "1" : "0");
    Serial.print(",");
    Serial.print(dirState ? "1" : "0");
    Serial.print(",");
    Serial.print(expositionTime);
    Serial.print(",");
    Serial.print(speedPercent);
    Serial.print(",");
    Serial.print(counterValue);
    Serial.print(",");
    Serial.print(totalCounterValue);
    Serial.print(",");
    Serial.print(hvState ? "1" : "0");
    Serial.print(",");
    
    // Время работы насоса
    if (pumpState && pumpTimerActive) {
      unsigned long elapsed = (millis() - pumpOnTime) / 1000;
      Serial.print(elapsed);
    } else {
      Serial.print("0");
    }
    Serial.print(",");
    
    // Напряжение HV
    Serial.print(lastHvVoltage, 2);
    Serial.print(",");
    
    // Фоновое излучение
    Serial.print(backgroundSavedValue);
    
    Serial.println();
  }
  else if (cmd == "GET:PUMPTIME") {
    sendPumpTime();
  }
  else if (cmd == "GET:PUMP") {
    Serial.println(pumpState ? "1" : "0");
  }
  else if (cmd == "GET:DIR") {
    Serial.println(dirState ? "1" : "0");
  }
  else if (cmd == "GET:EXPO") {
    Serial.println(expositionTime);
  }
  else if (cmd == "GET:SPEED") {
    Serial.println(speedPercent);
  }
  else if (cmd == "GET:COUNTER") {
    Serial.println(counterValue);
  }
  else if (cmd == "GET:TOTAL") {
    Serial.println(totalCounterValue);
  }
  else if (cmd == "GET:HV") {
    Serial.println(lastHvVoltage, 2);
  }
  else if (cmd == "GET:BACKGROUND") {
    Serial.println(backgroundSavedValue);
  }
  else if (cmd == "GET:BACKGROUND_STATUS") {
    if (backgroundMeasureActive) {
      Serial.println("MEASURING");
    } else if (currentMode == MODE_BACKGROUND_DONE) {
      Serial.println("DONE");
    } else {
      Serial.println("IDLE");
    }
  }
  else if (cmd == "SET:PUMP:ON") {
    if (!pumpState) {
      togglePump();
      Serial.println("OK:PUMP_ON");
    } else {
      Serial.println("OK:PUMP_ALREADY_ON");
    }
  }
  else if (cmd == "SET:PUMP:OFF") {
    if (pumpState) {
      togglePump();
      Serial.println("OK:PUMP_OFF");
    } else {
      Serial.println("OK:PUMP_ALREADY_OFF");
    }
  }
  else if (cmd == "SET:DIR:LEFT") {
    if (!dirState) {
      toggleDir();
      Serial.println("OK:DIR_LEFT");
    } else {
      Serial.println("OK:DIR_ALREADY_LEFT");
    }
  }
  else if (cmd == "SET:DIR:RIGHT") {
    if (dirState) {
      toggleDir();
      Serial.println("OK:DIR_RIGHT");
    } else {
      Serial.println("OK:DIR_ALREADY_RIGHT");
    }
  }
  else if (cmd.startsWith("SET:EXPO:")) {
    float val = cmd.substring(9).toFloat();
    bool valid = false;
    for (int i = 0; i < expoCount; i++) {
      if (abs(expoValues[i] - val) < 0.01) {
        valid = true;
        break;
      }
    }
    if (valid && val >= 0.5 && val <= 120) {
      expositionTime = val;
      expoIndex = findExpoIndex(expositionTime);
      saveSettings();
      
      // ===== ОБНОВЛЯЕМ ЭКРАН =====
      // Если мы в режиме меню - обновляем отображение экспозиции
      if (currentMode == MODE_MENU) {
        needRedrawMenu = true;
      } 
      // Если мы в режиме настройки экспозиции - обновляем экран настройки
      else if (currentMode == MODE_SET_EXPOSITION) {
        updateExpositionDisplay();
      }
      
      Serial.print("OK:EXPO=");
      Serial.println(expositionTime);
    } else {
      Serial.println("ERROR:INVALID_EXPO_VALUE");
    }
  }
  else if (cmd.startsWith("SET:SPEED:")) {
    int val = cmd.substring(10).toInt();
    if (val >= 0 && val <= 100 && val % 10 == 0) {
      speedPercent = val;
      setPWMDutyCycle(speedPercent);
      saveSettings();
      
      // ===== ОБНОВЛЯЕМ ЭКРАН =====
      // Если мы в режиме меню - обновляем отображение скорости
      if (currentMode == MODE_MENU) {
        needRedrawMenu = true;
      } 
      // Если мы в режиме настройки скорости - обновляем экран настройки
      else if (currentMode == MODE_SET_SPEED) {
        updateSpeedDisplay();
      }
      
      Serial.print("OK:SPEED=");
      Serial.println(speedPercent);
    } else {
      Serial.println("ERROR:INVALID_SPEED_VALUE");
    }
  }
  else if (cmd == "RESET:TOTAL") {
    totalCounterValue = 0;
    saveSettings();
    lastTotalValue = 0;
    
    // ===== ОБНОВЛЯЕМ ЭКРАН =====
    if (currentMode == MODE_MENU) {
      forceUpdateTotalDisplay();
    }
    
    Serial.println("OK:TOTAL_RESET");
  }
  else if (cmd == "BACKGROUND:START") {
    // Запускаем замер с USB
    backgroundMeasureFromUSB = true;
    startBackgroundMeasure();
    Serial.println("OK:BACKGROUND_STARTED");
  }
  else if (cmd == "BACKGROUND:STOP") {
    // Останавливаем замер
    stopBackgroundMeasure();
    Serial.println("OK:BACKGROUND_STOPPED");
  }
  else if (cmd == "PING") {
    Serial.println("PONG");
  }
  else {
    Serial.println("ERROR:UNKNOWN_COMMAND");
  }
}

// ===== ФУНКЦИЯ: ОСТАНОВКА ЗАМЕРА ФОНА С СОХРАНЕНИЕМ РЕЗУЛЬТАТА =====
void stopBackgroundMeasure() {
  if (backgroundMeasureActive || currentMode == MODE_BACKGROUND_MEASURE) {
    // Сохраняем текущее значение фона перед остановкой
    if (backgroundPulsesPerMinute > 0) {
      backgroundSavedValue = backgroundPulsesPerMinute;
      Serial.print("Background value saved: ");
      Serial.println(backgroundSavedValue);
    } else {
      // Если значение 0, пробуем вычислить заново
      unsigned long elapsed = millis() - backgroundMeasureStartTime;
      if (elapsed > 0) {
        float minutesPassed = elapsed / 60000.0;
        int calculatedValue = (int)(backgroundTotalPulses / minutesPassed);
        if (calculatedValue > 0) {
          backgroundSavedValue = calculatedValue;
          Serial.print("Background value calculated and saved: ");
          Serial.println(backgroundSavedValue);
        }
      }
    }
    
    backgroundMeasureActive = false;
    currentMode = MODE_MENU;
    selectedItem = 0;
    needRedrawMenu = true;
    backgroundMeasureFromUSB = false;
    Serial.println("Background measurement stopped with value saved");
  } else {
    Serial.println("No active background measurement");
  }
}

void sendPumpTime() {
  if (pumpState && pumpTimerActive) {
    unsigned long elapsed = (millis() - pumpOnTime) / 1000;
    int minutes = elapsed / 60;
    int seconds = elapsed % 60;
    Serial.print(minutes);
    Serial.print(":");
    Serial.println(seconds);
  } else {
    Serial.println("0:0");
  }
}

// ==================== ЛОГОТИП ====================
void showLogo() {
  tft.fillScreen(ST77XX_BLACK);

  int screenWidth = tft.width();
  int screenHeight = tft.height();
  int logoWidth = 120;
  int logoHeight = 120;
  int x = (screenWidth - logoWidth) / 2;
  int y = (screenHeight - logoHeight) / 2;

  tft.drawRGBBitmap(x, y, image_data_120x120, logoWidth, logoHeight);
}

// ==================== ФОНОВЫЙ ЗАМЕР ====================

void drawBackgroundPrompt() {
  drawBackgroundPromptWithSelection(0);
}

void startBackgroundMeasure() {
  backgroundMeasureActive = true;
  backgroundMeasureStartTime = millis();
  lastBackgroundDisplayUpdate = 0;
  backgroundTotalPulses = 0;
  backgroundPulsesPerMinute = 0;
  backgroundLastTriggerState = false;

  currentMode = MODE_BACKGROUND_MEASURE;

  drawBackgroundMeasure();
}

void processBackgroundMeasure() {
  unsigned long now = millis();
  unsigned long elapsed = now - backgroundMeasureStartTime;

  // 5 минут закончились
  if (elapsed >= BACKGROUND_MEASURE_TIME) {
    finishBackgroundMeasure();
    return;
  }

  // Считываем импульсы с COUNT_PIN
  int adcValue = analogRead(COUNT_PIN);
  float voltage = adcValue * (ADC_VOLTAGE / ADC_MAX);
  bool currentState = (voltage < VOLTAGE_THRESHOLD);

  if (currentState && !backgroundLastTriggerState) {
    backgroundTotalPulses++;
  }

  backgroundLastTriggerState = currentState;

  // Вычисляем импульсы в минуту (среднее)
  if (elapsed > 0) {
    float minutesPassed = elapsed / 60000.0;
    backgroundPulsesPerMinute = (int)(backgroundTotalPulses / minutesPassed);
  }

  // Обновляем экран раз в секунду
  if (now - lastBackgroundDisplayUpdate >= BACKGROUND_UPDATE_INTERVAL) {
    lastBackgroundDisplayUpdate = now;
    updateBackgroundDisplay();
  }
}

void drawBackgroundMeasure() {
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(8, 8);
  tft.print("BACKGROUND(BKG)");
  
  // HV индикатор
  drawBackgroundHVIndicator();

  tft.setCursor(8, 20);
  tft.print("RADIATION MEASURE");

  tft.drawLine(5, 32, SCREEN_WIDTH - 5, 32, ST77XX_CYAN);

  // Таймер (заголовок)
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(8, 43);
  tft.print("TIME LEFT:");

  // Таймер (значение) - будет обновляться
  tft.setTextSize(3);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.setCursor(22, 55);
  tft.print("00:00");

  // Импульсы (заголовок)
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(8, 90);
  tft.print("Counts per minute:");

  // Импульсы (значение) - будет обновляться
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
  tft.setCursor(22, 102);
  tft.print("0");

  // Напряжение HV (заголовок)
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(8, 138);
  tft.print("HV: ");

  // Напряжение HV (значение) - будет обновляться
  tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
  tft.setCursor(35, 138);
  tft.print("0.00V");

  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.setCursor(8, 150);
  tft.print("Measuring...");
}

void updateBackgroundDisplay() {
  unsigned long elapsed = millis() - backgroundMeasureStartTime;
  if (elapsed > BACKGROUND_MEASURE_TIME) elapsed = BACKGROUND_MEASURE_TIME;

  unsigned long remaining = BACKGROUND_MEASURE_TIME - elapsed;
  int minutes = remaining / 60000UL;
  int seconds = (remaining % 60000UL) / 1000UL;

  // Получаем текущее напряжение HV
  int adcValue = analogRead(SENSOR_VN);
  float voltage = adcValue * (ADC_VOLTAGE / ADC_MAX);
  lastHvVoltage = voltage;
  bool newHvState = (voltage > HV_THRESHOLD);
  
  // Обновляем HV состояние если изменилось
  if (newHvState != hvState) {
    hvState = newHvState;
    drawBackgroundHVIndicator();
  }

  // Обновляем таймер (формат MM:SS)
  static int lastMinutes = -1;
  static int lastSeconds = -1;
  
  if (minutes != lastMinutes || seconds != lastSeconds) {
    lastMinutes = minutes;
    lastSeconds = seconds;
    
    // Очищаем область таймера
    tft.fillRect(22, 55, 84, 30, ST77XX_BLACK);
    
    tft.setTextSize(3);
    tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
    tft.setCursor(22, 55);
    
    if (minutes < 10) tft.print("0");
    tft.print(minutes);
    tft.print(":");
    if (seconds < 10) tft.print("0");
    tft.print(seconds);
  }

  // Обновляем значение CPM
  static int lastCpmValue = -1;
  if (backgroundPulsesPerMinute != lastCpmValue) {
    lastCpmValue = backgroundPulsesPerMinute;
    
    // Очищаем область CPM
    tft.fillRect(22, 102, 80, 20, ST77XX_BLACK);
    
    tft.setTextSize(2);
    tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
    tft.setCursor(22, 102);
    tft.print(backgroundPulsesPerMinute);
  }

  // Обновляем напряжение HV (если изменилось)
  static float lastDisplayedVoltage = -1.0f;
  if (abs(voltage - lastDisplayedVoltage) > 0.01) {
    lastDisplayedVoltage = voltage;
    
    // Очищаем область напряжения
    tft.fillRect(35, 138, 60, 12, ST77XX_BLACK);
    
    tft.setTextSize(1);
    tft.setCursor(35, 138);
    if (hvState) {
      tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
    } else {
      tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
    }
    tft.print(voltage, 2);
    tft.print("V");
  }
}

void drawBackgroundHVIndicator() {
  int x = SCREEN_WIDTH - 5;
  int y = 4;

  tft.fillRect(x, y, 52, 14, ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(x, y + 2);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("HV");

  int squareX = x + 20;
  int squareY = y + 2;

  if (hvState) {
    // Зеленый квадрат при норме
    tft.fillRect(squareX, squareY, 8, 8, ST77XX_GREEN);
    tft.drawRect(squareX, squareY, 8, 8, ST77XX_WHITE);
  } else {
    // Мигающий красный при ошибке
    if (hvBlinkState) {
      tft.fillRect(squareX, squareY, 8, 8, ST77XX_RED);
      tft.drawRect(squareX, squareY, 8, 8, ST77XX_WHITE);
    } else {
      tft.fillRect(squareX, squareY, 8, 8, ST77XX_BLACK);
      tft.drawRect(squareX, squareY, 8, 8, ST77XX_RED);
    }
  }
}

void finishBackgroundMeasure() {
  backgroundMeasureActive = false;

  // Сохраняем результат
  backgroundSavedValue = backgroundPulsesPerMinute;
  Serial.print("Background measurement finished. Value: ");
  Serial.println(backgroundSavedValue);

  currentMode = MODE_BACKGROUND_DONE;

  // Если замер запущен с USB - сразу переходим в меню без показа экрана завершения
  if (backgroundMeasureFromUSB) {
    currentMode = MODE_MENU;
    selectedItem = 0;
    needRedrawMenu = true;
    backgroundMeasureFromUSB = false;
    return;
  }

  // Показываем экран завершения (только если замер не с USB)
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextSize(2);
  tft.setCursor(5, 20);
  tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
  tft.print("Measurement");
  tft.setCursor(5, 45);
  tft.print("Complete!");

  tft.setTextSize(1);
  tft.setCursor(5, 80);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("Background radiation:");

  tft.setTextSize(3);
  tft.setCursor(5, 100);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print(backgroundSavedValue);

  tft.setTextSize(1);
  tft.setCursor(80, 112);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("CPM");

  // Показываем финальное напряжение
  tft.setTextSize(1);
  tft.setCursor(5, 132);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("HV: ");
  if (hvState) {
    tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
  } else {
    tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
  }
  tft.print(lastHvVoltage, 2);
  tft.print("V");

  tft.setTextSize(1);
  tft.setCursor(5, 144);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Press to continue");
}

void readBackgroundDone() {
  bool currentButtonState = digitalRead(ENC_KEY);

  if (lastButtonState == HIGH && currentButtonState == LOW) {
    buttonPressTime = millis();
    buttonProcessed = false;
  }

  if (currentButtonState == LOW && !buttonProcessed && (millis() - buttonPressTime) >= 50) {
    buttonProcessed = true;
    currentMode = MODE_MENU;
    selectedItem = 0;
    needRedrawMenu = true;
  }

  lastButtonState = currentButtonState;
}

void drawBackgroundValue() {
  int x = 78;
  int y = 8;

  tft.fillRect(50, y, 28, 12, ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(75, y + 2);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.print("BKG:");

  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print(backgroundSavedValue);
}

// ==================== EEPROM ====================
void saveSettings() {
  EEPROM.put(EEPROM_ADDR_EXPOSITION, expositionTime);
  EEPROM.put(EEPROM_ADDR_SPEED, speedPercent);
  EEPROM.put(EEPROM_ADDR_TOTAL_COUNTER, totalCounterValue);
  EEPROM.commit();
  Serial.println("Settings saved to EEPROM");
}

void loadSettings() {
  float savedExposition = 30.0;
  int savedSpeed = 0;
  long savedTotalCounter = 0;

  EEPROM.get(EEPROM_ADDR_EXPOSITION, savedExposition);
  EEPROM.get(EEPROM_ADDR_SPEED, savedSpeed);
  EEPROM.get(EEPROM_ADDR_TOTAL_COUNTER, savedTotalCounter);

  bool valid = false;
  for (int i = 0; i < expoCount; i++) {
    if (abs(expoValues[i] - savedExposition) < 0.01) {
      valid = true;
      break;
    }
  }

  if (valid && savedExposition >= 0.5 && savedExposition <= 120) {
    expositionTime = savedExposition;
  } else {
    expositionTime = 30.0;
  }

  if (savedSpeed >= 0 && savedSpeed <= 100 && savedSpeed % 10 == 0) {
    speedPercent = savedSpeed;
  } else {
    speedPercent = 0;
  }

  if (savedTotalCounter >= 0) {
    totalCounterValue = savedTotalCounter;
  } else {
    totalCounterValue = 0;
  }

  // Фон всегда 0 при старте
  backgroundSavedValue = 0;

  setPWMDutyCycle(speedPercent);
  Serial.println("Settings loaded from EEPROM");
}

// ==================== HV ДАТЧИК ====================
void updateHVStatus() {
  if (millis() - lastHvUpdate >= HV_UPDATE_INTERVAL) {
    lastHvUpdate = millis();

    int adcValue = analogRead(SENSOR_VN);
    float voltage = adcValue * (ADC_VOLTAGE / ADC_MAX);
    lastHvVoltage = voltage;  // Сохраняем напряжение
    hvState = (voltage > HV_THRESHOLD);

    if (hvState != lastHvState) {
      lastHvState = hvState;
      if (currentMode == MODE_MENU) {
        drawHVIndicator();
      } else if (currentMode == MODE_BACKGROUND_MEASURE) {
        drawBackgroundHVIndicator();
      }
    }
  }

  if (!hvState) {
    if (millis() - lastHvBlinkTime >= 500) {
      lastHvBlinkTime = millis();
      hvBlinkState = !hvBlinkState;
      if (currentMode == MODE_MENU) {
        drawHVIndicator();
      } else if (currentMode == MODE_BACKGROUND_MEASURE) {
        drawBackgroundHVIndicator();
      }
    }
  } else {
    hvBlinkState = false;
  }
}

void drawUSBIndicator() {
  int x = 50;
  int y = 8;

  tft.fillRect(x, y, 25, 10, ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(x, y + 2);

  if (usbPollingActive) {
    tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
    tft.print("USB");
  }
}

void drawHVIndicator() {
  int x = SCREEN_WIDTH - 5;
  int y = 8;

  tft.fillRect(x, y, 50, 12, ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(x, y + 2);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("HV");

  int squareX = x + 20;
  int squareY = y + 2;

  if (hvState) {
    tft.fillRect(squareX, squareY, 6, 6, ST77XX_GREEN);
    tft.drawRect(squareX, squareY, 6, 6, ST77XX_WHITE);
  } else {
    if (hvBlinkState) {
      tft.fillRect(squareX, squareY, 6, 6, ST77XX_RED);
      tft.drawRect(squareX, squareY, 6, 6, ST77XX_WHITE);
    } else {
      tft.fillRect(squareX, squareY, 6, 6, ST77XX_BLACK);
      tft.drawRect(squareX, squareY, 6, 6, ST77XX_WHITE);
    }
  }
}

void updateUsbPollingStatus() {
  if (currentMode == MODE_MENU) {
    drawUSBIndicator();
  }
}

// ==================== ШИМ СКОРОСТЬ ====================
void setPWMDutyCycle(int percent) {
  int dutyCycle = map(percent, 0, 100, 0, 255);
  analogWrite(SPEED_PIN, dutyCycle);
}

// ==================== ОБРАБОТКА СЧЕТА ====================
void processCounting() {
  if (!countingActive && pumpState) {
    counterValue = 0;
    countingActive = true;
    countingStartTime = millis();
    lastTriggerState = false;
    resultShown = false;
    lastDisplayedCounterValue = -1;
    updateCounterAndTotalDisplay();
  }

  if (countingActive) {
    unsigned long requiredTime = (unsigned long)(expositionTime * 1000);
    if (millis() - countingStartTime >= requiredTime) {
      countingActive = false;
      resultShown = true;
      resultDisplayTime = millis();

      totalCounterValue += counterValue;
      saveSettings();

      forceUpdateTotalDisplay();

      return;
    }

    int adcValue = analogRead(COUNT_PIN);
    float voltage = adcValue * (ADC_VOLTAGE / ADC_MAX);
    bool currentState = (voltage < VOLTAGE_THRESHOLD);

    if (currentState == true && lastTriggerState == false) {
      counterValue++;
      updateCounterAndTotalDisplay();
    }

    lastTriggerState = currentState;
  }
}

// ==================== ОБРАБОТКА ЭНКОДЕРА И КНОПКИ (МЕНЮ) ====================
void readEncoderMenu() {
  int encState = digitalRead(ENC_S1);

  if (encState != lastEncState && (millis() - lastDebounceTime) > ENCODER_DEBOUNCE_DELAY) {
    lastDebounceTime = millis();

    int encB = digitalRead(ENC_S2);

    if (encB != encState) {
      encoderCounter++;
      if (encoderCounter >= ENCODER_SENSITIVITY) {
        selectedItem++;
        if (selectedItem >= menuItems) selectedItem = 0;
        encoderCounter = 0;
        needRedrawMenu = true;
      }
    } else {
      encoderCounter--;
      if (encoderCounter <= -ENCODER_SENSITIVITY) {
        selectedItem--;
        if (selectedItem < 0) selectedItem = menuItems - 1;
        encoderCounter = 0;
        needRedrawMenu = true;
      }
    }
  }

  lastEncState = encState;
}

void readButtonMenu() {
  bool currentButtonState = digitalRead(ENC_KEY);

  // Долгое нажатие для сброса общего счетчика
  if (selectedItem == 3 && currentButtonState == LOW && lastButtonState == HIGH) {
    totalResetStartTime = millis();
    totalResetRequested = true;
  }

  if (selectedItem == 3 && totalResetRequested && currentButtonState == LOW) {
    if (millis() - totalResetStartTime >= LONG_PRESS_TIME) {
      totalCounterValue = 0;
      lastTotalValue = 0;
      saveSettings();
      totalResetRequested = false;
      forceUpdateTotalDisplay();
      showMessage("TOTAL RESET!", "Counter cleared");
    }
  }

  if (currentButtonState == HIGH && totalResetRequested) {
    totalResetRequested = false;
    if (selectedItem == 3) {
      needRedrawMenu = true;
    }
  }

  // Короткое нажатие для обычных действий
  if (lastButtonState == HIGH && currentButtonState == LOW && selectedItem != 3) {
    buttonPressTime = millis();
    buttonProcessed = false;
  }

  if (currentButtonState == LOW && !buttonProcessed && (millis() - buttonPressTime) >= LONG_PRESS_TIME && selectedItem != 3) {
    buttonProcessed = true;

    if (selectedItem == 0) {
      togglePump();
    } else if (selectedItem == 1) {
      toggleDir();
    } else if (selectedItem == 2) {
      if (!pumpState) {
        currentMode = MODE_SET_EXPOSITION;
        updateExpositionDisplay();
      } else {
        showMessage("Cannot edit!", "PUMP is ON");
      }
    } else if (selectedItem == 4) {
      currentMode = MODE_SET_SPEED;
      updateSpeedDisplay();
    }
  }

  lastButtonState = currentButtonState;
}

// ==================== НАСТРОЙКА ЭКСПОЗИЦИИ ====================
int findExpoIndex(float value) {
  for (int i = 0; i < expoCount; i++) {
    if (abs(expoValues[i] - value) < 0.01) {
      return i;
    }
  }
  return 4;
}

void readEncoderExposition() {
  int encState = digitalRead(ENC_S1);
  bool changed = false;

  if (encState != lastEncState && (millis() - lastDebounceTime) > ENCODER_DEBOUNCE_DELAY) {
    lastDebounceTime = millis();

    int encB = digitalRead(ENC_S2);

    if (encB != encState) {
      encoderCounter++;
      if (encoderCounter >= ENCODER_SENSITIVITY) {
        if (expoIndex < expoCount - 1) {
          expoIndex++;
          expositionTime = expoValues[expoIndex];
          changed = true;
        }
        encoderCounter = 0;
        if (changed) {
          updateExpositionDisplay();
          saveSettings();
        }
      }
    } else {
      encoderCounter--;
      if (encoderCounter <= -ENCODER_SENSITIVITY) {
        if (expoIndex > 0) {
          expoIndex--;
          expositionTime = expoValues[expoIndex];
          changed = true;
        }
        encoderCounter = 0;
        if (changed) {
          updateExpositionDisplay();
          saveSettings();
        }
      }
    }
  }

  lastEncState = encState;
}

void readButtonExposition() {
  bool currentButtonState = digitalRead(ENC_KEY);

  if (lastButtonState == HIGH && currentButtonState == LOW) {
    buttonPressTime = millis();
    buttonProcessed = false;
  }

  if (currentButtonState == LOW && !buttonProcessed && (millis() - buttonPressTime) >= LONG_PRESS_TIME) {
    buttonProcessed = true;
    currentMode = MODE_MENU;
    needRedrawMenu = true;
  }

  lastButtonState = currentButtonState;
}

// ==================== НАСТРОЙКА СКОРОСТИ ====================
void readEncoderSpeed() {
  int encState = digitalRead(ENC_S1);
  bool changed = false;

  if (encState != lastEncState && (millis() - lastDebounceTime) > ENCODER_DEBOUNCE_DELAY) {
    lastDebounceTime = millis();

    int encB = digitalRead(ENC_S2);

    if (encB != encState) {
      encoderCounter++;
      if (encoderCounter >= ENCODER_SENSITIVITY) {
        if (speedPercent < 100) {
          speedPercent += 10;
          if (speedPercent > 100) speedPercent = 100;
          setPWMDutyCycle(speedPercent);
          changed = true;
        }
        encoderCounter = 0;
        if (changed) {
          updateSpeedDisplay();
          saveSettings();
        }
      }
    } else {
      encoderCounter--;
      if (encoderCounter <= -ENCODER_SENSITIVITY) {
        if (speedPercent > 0) {
          speedPercent -= 10;
          if (speedPercent < 0) speedPercent = 0;
          setPWMDutyCycle(speedPercent);
          changed = true;
        }
        encoderCounter = 0;
        if (changed) {
          updateSpeedDisplay();
          saveSettings();
        }
      }
    }
  }

  lastEncState = encState;
}

void readButtonSpeed() {
  bool currentButtonState = digitalRead(ENC_KEY);

  if (lastButtonState == HIGH && currentButtonState == LOW) {
    buttonPressTime = millis();
    buttonProcessed = false;
  }

  if (currentButtonState == LOW && !buttonProcessed && (millis() - buttonPressTime) >= LONG_PRESS_TIME) {
    buttonProcessed = true;
    currentMode = MODE_MENU;
    needRedrawMenu = true;
  }

  lastButtonState = currentButtonState;
}

// ==================== УПРАВЛЕНИЕ НАСОСОМ И НАПРАВЛЕНИЕМ ====================
void togglePump() {
  pumpState = !pumpState;

  if (pumpState) {
    pumpOnTime = millis();
    pumpTimerActive = true;
    lastTimerUpdate = millis();
    lastDisplayedMinutes = -1;
    lastDisplayedSeconds = -1;
    Serial.println("Pump turned ON");
  } else {
    pumpTimerActive = false;
    countingActive = false;
    counterValue = 0;
    resultShown = false;
    lastDisplayedCounterValue = -1;
    Serial.println("Pump turned OFF");
  }

  needRedrawMenu = true;

  digitalWrite(PUMP_PIN, HIGH);
  delay(500);
  digitalWrite(PUMP_PIN, LOW);
}

void toggleDir() {
  dirState = !dirState;
  needRedrawMenu = true;
  Serial.print("Direction changed to: ");
  Serial.println(dirState ? "LEFT" : "RIGHT");

  digitalWrite(DIR_PIN, HIGH);
  delay(500);
  digitalWrite(DIR_PIN, LOW);
}

// ==================== ФУНКЦИИ ОБНОВЛЕНИЯ ЭКРАНА ====================
void showMessage(String line1, String line2) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextSize(1);
  tft.setCursor(10, 60);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print(line1);
  tft.setCursor(10, 80);
  tft.print(line2);
  delay(1500);
  needRedrawMenu = true;
}

void updatePumpTimerDisplay() {
  if (!pumpTimerActive) return;

  unsigned long elapsed = (millis() - pumpOnTime) / 1000;
  int minutes = elapsed / 60;
  int seconds = elapsed % 60;

  if (minutes == lastDisplayedMinutes && seconds == lastDisplayedSeconds) {
    return;
  }

  lastDisplayedMinutes = minutes;
  lastDisplayedSeconds = seconds;

  tft.fillRect(0, 100, SCREEN_WIDTH, 30, ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(5, 108);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.print("TIME:");

  tft.setTextSize(2);
  tft.setCursor(55, 102);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);

  if (minutes > 0) {
    if (minutes < 10) tft.print(" ");
    tft.print(minutes);
    tft.setTextSize(1);
    tft.setCursor(85, 110);
    tft.print("m");

    tft.setTextSize(2);
    tft.setCursor(100, 102);
    if (seconds < 10) tft.print("0");
    tft.print(seconds);
    tft.setTextSize(1);
    tft.setCursor(125, 110);
    tft.print("s");
  } else {
    if (seconds < 10) tft.print(" ");
    tft.print(seconds);
    tft.setTextSize(1);
    tft.setCursor(85, 110);
    tft.print("sec");
  }
}

void drawMenuTitle() {
  tft.fillRect(0, 0, SCREEN_WIDTH, 22, ST77XX_BLACK);

  // MENU
  tft.setTextSize(2);
  tft.setCursor(2, 3);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.print("MENU");

  // USB (если активен)
  drawUSBIndicator();

  // Значение фона
  drawBackgroundValue();

  // HV индикатор
  drawHVIndicator();

  tft.drawLine(2, 20, SCREEN_WIDTH - 2, 20, ST77XX_CYAN);
}

void updateCounterAndTotalDisplay() {
  if (currentMode != MODE_MENU) return;

  int y4 = 74;
  String countDisplay;

  if (resultShown) {
    countDisplay = "COUNTER:" + String(counterValue);
  } else if (!pumpState) {
    countDisplay = "COUNTER:OFF";
  } else if (countingActive) {
    countDisplay = "COUNTER:" + String(counterValue);
  } else {
    countDisplay = "COUNTER:0";
  }

  String totalDisplay = "TOTAL:" + String(totalCounterValue);

  if (selectedItem == 3) {
    // Перерисовываем ТОЛЬКО если изменились значения
    if (lastDisplayedCounterValue != counterValue || lastTotalValue != totalCounterValue) {
      tft.fillRect(1, y4 - 3, 125, 14, ST77XX_BLUE);
      tft.setCursor(10, y4);
      tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
      tft.print(countDisplay);
      tft.setCursor(85, y4);
      tft.print(totalDisplay);
      lastDisplayedCounterValue = counterValue;
      lastTotalValue = totalCounterValue;
    }
  } else {
    // Обновляем только если изменилось
    if (lastDisplayedCounterValue != counterValue) {
      tft.fillRect(10, y4 - 3, 75, 14, ST77XX_BLACK);
      tft.setCursor(10, y4);
      tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
      tft.print(countDisplay);
      lastDisplayedCounterValue = counterValue;
    }

    if (lastTotalValue != totalCounterValue) {
      tft.fillRect(85, y4 - 3, 45, 14, ST77XX_BLACK);
      tft.setCursor(85, y4);
      tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
      tft.print(totalDisplay);
      lastTotalValue = totalCounterValue;
    }
  }
}

void forceUpdateTotalDisplay() {
  if (currentMode != MODE_MENU) return;

  int y4 = 74;
  String totalDisplay = "TOTAL:" + String(totalCounterValue);

  if (selectedItem == 3) {
    String countDisplay;
    if (resultShown) {
      countDisplay = "COUNTER:" + String(counterValue);
    } else if (!pumpState) {
      countDisplay = "COUNTER:OFF";
    } else if (countingActive) {
      countDisplay = "COUNTER:" + String(counterValue);
    } else {
      countDisplay = "COUNTER:0";
    }

    tft.fillRect(1, y4 - 3, 125, 14, ST77XX_BLUE);
    tft.setCursor(10, y4);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print(countDisplay);
    tft.setCursor(85, y4);
    tft.print(totalDisplay);
    lastDisplayedCounterValue = counterValue;
  } else {
    tft.fillRect(85, y4 - 3, 45, 14, ST77XX_BLACK);
    tft.setCursor(85, y4);
    tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
    tft.print(totalDisplay);
  }

  lastTotalValue = totalCounterValue;
}

void updateDynamicValuesOnly() {
  if (pumpTimerActive && pumpState) {
    updatePumpTimerDisplay();
  }

  updateCounterAndTotalDisplay();
}

void fullRedraw() {
  tft.fillScreen(ST77XX_BLACK);

  drawMenuTitle();

  tft.setTextSize(1);

  // PUMP
  int y1 = 26;
  if (selectedItem == 0) {
    tft.fillRect(1, y1 - 3, 85, 14, ST77XX_BLUE);
    tft.setCursor(10, y1);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print(pumpState ? "PUMP:ON" : "PUMP:OFF");
  } else {
    tft.setCursor(10, y1);
    tft.setTextColor(pumpState ? ST77XX_GREEN : ST77XX_RED, ST77XX_BLACK);
    tft.print(pumpState ? "PUMP:ON" : "PUMP:OFF");
  }

  // DIRECTION
  int y2 = 42;
  if (selectedItem == 1) {
    tft.fillRect(1, y2 - 3, 105, 14, ST77XX_BLUE);
    tft.setCursor(10, y2);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print(dirState ? "DIRECTION:LEFT" : "DIRECTION:RIGHT");
  } else {
    tft.setCursor(10, y2);
    tft.setTextColor(dirState ? ST77XX_GREEN : ST77XX_RED, ST77XX_BLACK);
    tft.print(dirState ? "DIRECTION:LEFT" : "DIRECTION:RIGHT");
  }

  // EXPOSITION
  int y3 = 58;
  String expoStr;
  if (expositionTime == (int)expositionTime) {
    expoStr = String((int)expositionTime);
  } else {
    expoStr = String(expositionTime, 1);
  }

  if (selectedItem == 2) {
    tft.fillRect(1, y3 - 3, 105, 14, ST77XX_BLUE);
    tft.setCursor(10, y3);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print("EXPOSITION:" + expoStr + "s");
  } else {
    tft.setCursor(10, y3);
    if (pumpState) {
      tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
      tft.print("EXPOSITION:" + expoStr + "s");
    } else {
      tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
      tft.print("EXPOSITION:" + expoStr + "s");
    }
  }

  // COUNTER & TOTAL
  int y4 = 74;
  String countDisplay;

  if (resultShown) {
    countDisplay = "COUNTER:" + String(counterValue);
  } else if (!pumpState) {
    countDisplay = "COUNTER:OFF";
  } else if (countingActive) {
    countDisplay = "COUNTER:" + String(counterValue);
  } else {
    countDisplay = "COUNTER:0";
  }

  String totalDisplay = "TOTAL:" + String(totalCounterValue);

  if (selectedItem == 3) {
    tft.fillRect(1, y4 - 3, 125, 14, ST77XX_BLUE);
    tft.setCursor(10, y4);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print(countDisplay);
    tft.setCursor(85, y4);
    tft.print(totalDisplay);
  } else {
    tft.setCursor(10, y4);
    tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
    tft.print(countDisplay);
    tft.setCursor(85, y4);
    tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
    tft.print(totalDisplay);
  }

  lastDisplayedCounterValue = counterValue;
  lastTotalValue = totalCounterValue;

  // SPEED
  int y5 = 90;
  if (selectedItem == 4) {
    tft.fillRect(1, y5 - 3, 100, 14, ST77XX_BLUE);
    tft.setCursor(10, y5);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print("SPEED:" + String(speedPercent) + "%");
  } else {
    tft.setCursor(10, y5);
    tft.setTextColor(ST77XX_MAGENTA, ST77XX_BLACK);
    tft.print("SPEED:" + String(speedPercent) + "%");
  }

  // Подсказки внизу
  tft.setTextSize(1);
  tft.drawRect(1, 140, 126, 18, ST77XX_BLUE);
  tft.setCursor(4, 144);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Rotate:Sel");
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print(" ");
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Hold:Act");

  if (selectedItem == 2 && pumpState) {
    tft.setCursor(4, 130);
    tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
    tft.print("Locked: PUMP ON");
  }

  lastPumpStateForRedraw = pumpState;
  lastDirStateForRedraw = dirState;
  lastExpositionValue = expositionTime;
  lastSpeedValue = speedPercent;
}

void updateExpositionDisplay() {
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(2, 3);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.print("SET EXPOSITION");
  tft.drawLine(2, 12, SCREEN_WIDTH - 2, 12, ST77XX_CYAN);

  tft.setTextSize(3);
  tft.setCursor(10, 40);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);

  if (expositionTime == (int)expositionTime) {
    if (expositionTime < 100) tft.print(" ");
    tft.print((int)expositionTime);
  } else {
    tft.print(expositionTime, 1);
  }

  tft.setTextSize(1);
  tft.setCursor(70, 52);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("seconds");

  int barWidth;
  if (expositionTime <= 1) {
    barWidth = map(expositionTime * 100, 10, 100, 5, 20);
    if (barWidth < 5) barWidth = 5;
  } else {
    barWidth = map(expositionTime, 10, 120, 20, 100);
  }
  tft.fillRect(5, 75, barWidth, 6, ST77XX_GREEN);
  tft.drawRect(5, 75, 100, 6, ST77XX_WHITE);

  for (float i = 0.5; i <= 120; i *= 10) {
    int x;
    if (i <= 1) {
      x = map(i * 100, 10, 100, 5, 20);
    } else {
      x = map(i, 10, 120, 20, 105);
    }
    if (x >= 5 && x <= 105) {
      tft.drawLine(x, 75, x, 81, ST77XX_WHITE);
    }
  }

  tft.setCursor(5, 90);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("0.5s");
  tft.setCursor(95, 90);
  tft.print("120s");

  tft.setCursor(5, 120);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("Hold to exit");

  tft.drawRect(1, 140, 126, 18, ST77XX_BLUE);
  tft.setCursor(4, 144);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Rotate:Change");
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print(" ");
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Hold:Back");
}

void updateSpeedDisplay() {
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(2, 3);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.print("SET SPEED");
  tft.drawLine(2, 12, SCREEN_WIDTH - 2, 12, ST77XX_CYAN);

  tft.setTextSize(3);
  tft.setCursor(25, 40);
  tft.setTextColor(ST77XX_MAGENTA, ST77XX_BLACK);

  if (speedPercent < 100) tft.print(" ");
  if (speedPercent < 10) tft.print(" ");
  tft.print(speedPercent);

  tft.setTextSize(1);
  tft.setCursor(85, 52);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("%");

  int barWidth = map(speedPercent, 0, 100, 10, 100);
  tft.fillRect(5, 75, barWidth, 12, ST77XX_MAGENTA);
  tft.drawRect(5, 75, 105, 12, ST77XX_WHITE);

  for (int i = 10; i <= 100; i += 10) {
    int x = map(i, 0, 100, 5, 110);
    tft.drawLine(x, 75, x, 87, ST77XX_WHITE);
  }

  tft.setCursor(5, 95);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("0%");
  tft.setCursor(90, 95);
  tft.print("100%");

  tft.setCursor(5, 120);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("Hold to exit");

  tft.drawRect(1, 140, 126, 18, ST77XX_BLUE);
  tft.setCursor(4, 144);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Rotate:Change");
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print(" ");
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Hold:Back");
}