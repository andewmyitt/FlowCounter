#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>
#include <EEPROM.h>
#include "RI_logo_image_120x120.h"

// ==================== ПИНЫ ====================
// Энкодер
#define ENC_S1 35
#define ENC_S2 32
#define ENC_KEY 34

// TFT экран
#define TFT_CS 5
#define TFT_RST 4
#define TFT_DC 2
#define TFT_SDA 23
#define TFT_SCK 18
#define TFT_LED 12

// Управление
#define PUMP_PIN 25
#define DIR_PIN 26
#define COUNT_PIN 36
#define SPEED_PIN 27
#define SENSOR_VN 39

// ==================== НАСТРОЙКИ ====================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 160

#define ENCODER_SENSITIVITY 3
#define ENCODER_DEBOUNCE_DELAY 5
#define LONG_PRESS_TIME 600

#define VOLTAGE_THRESHOLD 2.0
#define ADC_MAX 4095
#define ADC_VOLTAGE 3.3

#define HV_THRESHOLD 2.0f
#define HV_UPDATE_INTERVAL 200

#define EEPROM_SIZE 128
#define EEPROM_ADDR_EXPOSITION 0
#define EEPROM_ADDR_SPEED 4
#define EEPROM_ADDR_TOTAL_COUNTER 8

#define LOGO_SHOW_TIME 2000
#define USB_POLLING_TIMEOUT 2000

// ==================== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ====================
Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RST);

// Состояния
bool pumpState = false;
bool dirState = false;
float expositionTime = 30.0;  // Изменено на float для поддержки 0.1
int speedPercent = 0;

// Счетчики
int counterValue = 0;
long totalCounterValue = 0;
bool countingActive = false;
unsigned long countingStartTime = 0;
bool lastTriggerState = false;
bool resultShown = false;
unsigned long resultDisplayTime = 0;
int lastDisplayedCounterValue = -1;

// Таймер насоса
unsigned long pumpOnTime = 0;
bool pumpTimerActive = false;
unsigned long lastTimerUpdate = 0;
int lastDisplayedMinutes = -1;
int lastDisplayedSeconds = -1;

// Логотип
bool logoShown = true;
unsigned long logoStartTime = 0;

// HV датчик
bool hvState = false;
bool lastHvState = false;
unsigned long lastHvUpdate = 0;
unsigned long lastHvBlinkTime = 0;
bool hvBlinkState = false;

// USB опрос
unsigned long lastUsbCommandTime = 0;
bool usbPollingActive = false;

// Меню
int selectedItem = 0;
const int menuItems = 5;

enum SystemMode {
  MODE_MENU,
  MODE_SET_EXPOSITION,
  MODE_SET_SPEED
};
SystemMode currentMode = MODE_MENU;

// Кнопка и энкодер
bool lastButtonState = HIGH;
unsigned long buttonPressTime = 0;
bool buttonProcessed = false;
int lastEncState = 0;
int encoderCounter = 0;
unsigned long lastDebounceTime = 0;

bool totalResetRequested = false;
unsigned long totalResetStartTime = 0;
bool needRedrawMenu = true;

// Переменные для отслеживания изменений
float lastExpositionValue = -1;
int lastSpeedValue = -1;
long lastTotalValue = -1;
bool lastPumpStateForRedraw = false;
bool lastDirStateForRedraw = false;

// Массив допустимых значений экспозиции
const float expoValues[] = {0.1, 1, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120};
const int expoCount = sizeof(expoValues) / sizeof(expoValues[0]);
int expoIndex = 4; // Индекс значения 30

// ==================== ПРОТОТИПЫ ФУНКЦИЙ ====================
void showLogo();
void saveSettings();
void loadSettings();
void updateHVStatus();
void drawHVIndicator();
void drawUSBIndicator();
void drawMenuTitle();
void updateCounterAndTotalDisplay();
void forceUpdateTotalDisplay();
void setPWMDutyCycle(int percent);
void processCounting();
void readEncoderMenu();
void readButtonMenu();
void readEncoderExposition();
void readButtonExposition();
void readEncoderSpeed();
void readButtonSpeed();
void togglePump();
void toggleDir();
void showMessage(String line1, String line2);
void updatePumpTimerDisplay();
void fullRedraw();
void updateDynamicValuesOnly();
void updateExpositionDisplay();
void updateSpeedDisplay();
void processSerialCommand(String cmd);
void sendPumpTime();
void updateUsbPollingStatus();
int findExpoIndex(float value);

// ==================== НАСТРОЙКА ====================
void setup() {
  Serial.begin(38400);
  Serial.println("Device ready");

  EEPROM.begin(EEPROM_SIZE);

  pinMode(ENC_S1, INPUT_PULLUP);
  pinMode(ENC_S2, INPUT_PULLUP);
  pinMode(ENC_KEY, INPUT_PULLUP);
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(DIR_PIN, OUTPUT);
  pinMode(COUNT_PIN, INPUT);
  pinMode(SPEED_PIN, OUTPUT);
  pinMode(SENSOR_VN, INPUT);

  digitalWrite(PUMP_PIN, LOW);
  digitalWrite(DIR_PIN, LOW);
  analogWrite(SPEED_PIN, 0);

  tft.initR(INITR_BLACKTAB);
  tft.setRotation(1);

  pinMode(TFT_LED, OUTPUT);
  digitalWrite(TFT_LED, HIGH);

  showLogo();
  logoStartTime = millis();
  logoShown = true;

  loadSettings();

  lastEncState = digitalRead(ENC_S1);

  // Инициализируем переменные для отслеживания
  lastPumpStateForRedraw = pumpState;
  lastDirStateForRedraw = dirState;
  lastExpositionValue = expositionTime;
  lastSpeedValue = speedPercent;
  lastTotalValue = totalCounterValue;
  
  // Находим индекс текущего значения экспозиции
  expoIndex = findExpoIndex(expositionTime);
}

// ==================== ОСНОВНОЙ ЦИКЛ ====================
void loop() {
  // Показ логотипа при старте
  if (logoShown) {
    if (millis() - logoStartTime >= LOGO_SHOW_TIME) {
      logoShown = false;
      needRedrawMenu = true;
    }
    delay(10);
    return;
  }

  // Обработка команд с USB
  if (Serial.available()) {
    String command = Serial.readStringUntil('\n');
    command.trim();
    if (command.length() > 0) {
      lastUsbCommandTime = millis();
      if (!usbPollingActive) {
        usbPollingActive = true;
        updateUsbPollingStatus();
      }
      processSerialCommand(command);
    }
  }

  // Проверка таймаута USB опроса
  if (usbPollingActive && (millis() - lastUsbCommandTime >= USB_POLLING_TIMEOUT)) {
    usbPollingActive = false;
    updateUsbPollingStatus();
  }

  // Обновление статуса HV
  updateHVStatus();

  // Обработка счета импульсов
  if (pumpState) {
    processCounting();
  } else {
    if (countingActive) {
      countingActive = false;
      counterValue = 0;
      resultShown = false;
      lastDisplayedCounterValue = -1;
      updateCounterAndTotalDisplay();
    }
  }

  // Скрытие результата через 3 секунды
  if (resultShown && (millis() - resultDisplayTime >= 3000)) {
    resultShown = false;
    lastDisplayedCounterValue = -1;
    updateCounterAndTotalDisplay();
  }

  // Обработка ввода в зависимости от режима
  if (currentMode == MODE_MENU) {
    readEncoderMenu();
    readButtonMenu();
  } else if (currentMode == MODE_SET_EXPOSITION) {
    readEncoderExposition();
    readButtonExposition();
  } else if (currentMode == MODE_SET_SPEED) {
    readEncoderSpeed();
    readButtonSpeed();
  }

  // Обновление только динамических значений для меню
  if (currentMode == MODE_MENU) {
    updateDynamicValuesOnly();
  }

  // Полная перерисовка только когда действительно нужно
  if (needRedrawMenu) {
    needRedrawMenu = false;
    fullRedraw();
  }

  delay(10);
}

// ==================== USB КОМАНДНЫЙ ПРОТОКОЛ ====================
void processSerialCommand(String cmd) {
  Serial.print("CMD:");
  Serial.println(cmd);

  if (cmd == "GET:STATUS") {
    Serial.print("STATUS:");
    Serial.print(pumpState ? "1" : "0");
    Serial.print(",");
    Serial.print(dirState ? "1" : "0");
    Serial.print(",");
    Serial.print(expositionTime);
    Serial.print(",");
    Serial.print(speedPercent);
    Serial.print(",");
    Serial.print(counterValue);
    Serial.print(",");
    Serial.print(totalCounterValue);
    Serial.print(",");
    Serial.println(hvState ? "1" : "0");
  } else if (cmd == "GET:FULLSTATUS") {
    Serial.print("FULLSTATUS:");
    Serial.print(pumpState ? "1" : "0");
    Serial.print(",");
    Serial.print(dirState ? "1" : "0");
    Serial.print(",");
    Serial.print(expositionTime);
    Serial.print(",");
    Serial.print(speedPercent);
    Serial.print(",");
    Serial.print(counterValue);
    Serial.print(",");
    Serial.print(totalCounterValue);
    Serial.print(",");
    Serial.print(hvState ? "1" : "0");
    Serial.print(",");

    if (pumpState && pumpTimerActive) {
      unsigned long elapsed = (millis() - pumpOnTime) / 1000;
      Serial.print(elapsed);
    } else {
      Serial.print("0");
    }
    Serial.println();
  } else if (cmd == "GET:PUMPTIME") {
    sendPumpTime();
  } else if (cmd == "SET:PUMP:ON") {
    if (!pumpState) {
      togglePump();
      Serial.println("OK:PUMP_ON");
    } else {
      Serial.println("OK:PUMP_ALREADY_ON");
    }
  } else if (cmd == "SET:PUMP:OFF") {
    if (pumpState) {
      togglePump();
      Serial.println("OK:PUMP_OFF");
    } else {
      Serial.println("OK:PUMP_ALREADY_OFF");
    }
  } else if (cmd == "SET:DIR:LEFT") {
    if (!dirState) {
      toggleDir();
      Serial.println("OK:DIR_LEFT");
    } else {
      Serial.println("OK:DIR_ALREADY_LEFT");
    }
  } else if (cmd == "SET:DIR:RIGHT") {
    if (dirState) {
      toggleDir();
      Serial.println("OK:DIR_RIGHT");
    } else {
      Serial.println("OK:DIR_ALREADY_RIGHT");
    }
  } else if (cmd.startsWith("SET:EXPO:")) {
    float val = cmd.substring(9).toFloat();
    // Проверяем, есть ли такое значение в массиве
    bool valid = false;
    for (int i = 0; i < expoCount; i++) {
      if (abs(expoValues[i] - val) < 0.01) {
        valid = true;
        break;
      }
    }
    if (valid && val >= 0.1 && val <= 120) {
      expositionTime = val;
      expoIndex = findExpoIndex(expositionTime);
      saveSettings();
      Serial.print("OK:EXPO=");
      Serial.println(expositionTime);
      if (currentMode == MODE_SET_EXPOSITION) {
        updateExpositionDisplay();
      } else {
        needRedrawMenu = true;
      }
    } else {
      Serial.println("ERROR:INVALID_EXPO_VALUE");
    }
  } else if (cmd.startsWith("SET:SPEED:")) {
    int val = cmd.substring(10).toInt();
    if (val >= 0 && val <= 100 && val % 10 == 0) {
      speedPercent = val;
      setPWMDutyCycle(speedPercent);
      saveSettings();
      Serial.print("OK:SPEED=");
      Serial.println(speedPercent);
      if (currentMode == MODE_SET_SPEED) {
        updateSpeedDisplay();
      } else {
        needRedrawMenu = true;
      }
    } else {
      Serial.println("ERROR:INVALID_SPEED_VALUE");
    }
  } else if (cmd == "RESET:TOTAL") {
    totalCounterValue = 0;
    saveSettings();
    lastTotalValue = 0;
    Serial.println("OK:TOTAL_RESET");
    forceUpdateTotalDisplay();
  } else if (cmd == "GET:COUNTER") {
    Serial.print("COUNTER:");
    Serial.println(counterValue);
  } else if (cmd == "GET:TOTAL") {
    Serial.print("TOTAL:");
    Serial.println(totalCounterValue);
  } else if (cmd == "GET:HV") {
    Serial.print("HV:");
    Serial.println(hvState ? "1" : "0");
  } else if (cmd == "GET:EXPO") {
    Serial.print("EXPO:");
    Serial.println(expositionTime);
  } else if (cmd == "GET:SPEED") {
    Serial.print("SPEED:");
    Serial.println(speedPercent);
  } else if (cmd == "GET:PUMP") {
    Serial.print("PUMP:");
    Serial.println(pumpState ? "1" : "0");
  } else if (cmd == "GET:DIR") {
    Serial.print("DIR:");
    Serial.println(dirState ? "1" : "0");
  } else if (cmd == "PING") {
    Serial.println("PONG");
  } else {
    Serial.println("ERROR:UNKNOWN_COMMAND");
  }
}

void sendPumpTime() {
  if (pumpState && pumpTimerActive) {
    unsigned long elapsed = (millis() - pumpOnTime) / 1000;
    int minutes = elapsed / 60;
    int seconds = elapsed % 60;
    Serial.print("PUMPTIME:");
    Serial.print(minutes);
    Serial.print(":");
    Serial.println(seconds);
  } else {
    Serial.println("PUMPTIME:0:0");
  }
}

// ==================== ЛОГОТИП ====================
void showLogo() {
  tft.fillScreen(ST77XX_BLACK);

  int screenWidth = tft.width();
  int screenHeight = tft.height();
  int logoWidth = 120;
  int logoHeight = 120;
  int x = (screenWidth - logoWidth) / 2;
  int y = (screenHeight - logoHeight) / 2;

  tft.drawRGBBitmap(x, y, image_data_120x120, logoWidth, logoHeight);
}

// ==================== EEPROM ====================
void saveSettings() {
  EEPROM.put(EEPROM_ADDR_EXPOSITION, expositionTime);
  EEPROM.put(EEPROM_ADDR_SPEED, speedPercent);
  EEPROM.put(EEPROM_ADDR_TOTAL_COUNTER, totalCounterValue);
  EEPROM.commit();
  Serial.println("Settings saved to EEPROM");
}

void loadSettings() {
  float savedExposition = 30.0;
  int savedSpeed = 0;
  long savedTotalCounter = 0;

  EEPROM.get(EEPROM_ADDR_EXPOSITION, savedExposition);
  EEPROM.get(EEPROM_ADDR_SPEED, savedSpeed);
  EEPROM.get(EEPROM_ADDR_TOTAL_COUNTER, savedTotalCounter);

  // Проверяем, есть ли сохраненное значение в массиве допустимых
  bool valid = false;
  for (int i = 0; i < expoCount; i++) {
    if (abs(expoValues[i] - savedExposition) < 0.01) {
      valid = true;
      break;
    }
  }
  
  if (valid && savedExposition >= 0.1 && savedExposition <= 120) {
    expositionTime = savedExposition;
  } else {
    expositionTime = 30.0;
  }

  if (savedSpeed >= 0 && savedSpeed <= 100 && savedSpeed % 10 == 0) {
    speedPercent = savedSpeed;
  } else {
    speedPercent = 0;
  }

  if (savedTotalCounter >= 0) {
    totalCounterValue = savedTotalCounter;
  } else {
    totalCounterValue = 0;
  }

  setPWMDutyCycle(speedPercent);
  Serial.println("Settings loaded from EEPROM");
}

// ==================== HV ДАТЧИК ====================
void updateHVStatus() {
  if (millis() - lastHvUpdate >= HV_UPDATE_INTERVAL) {
    lastHvUpdate = millis();

    int adcValue = analogRead(SENSOR_VN);
    float voltage = adcValue * (ADC_VOLTAGE / ADC_MAX);
    hvState = (voltage > HV_THRESHOLD);

    if (hvState != lastHvState) {
      lastHvState = hvState;
      if (currentMode == MODE_MENU) {
        drawHVIndicator();
      }
    }
  }

  if (!hvState && currentMode == MODE_MENU) {
    if (millis() - lastHvBlinkTime >= 500) {
      lastHvBlinkTime = millis();
      hvBlinkState = !hvBlinkState;
      drawHVIndicator();
    }
  }
}

void drawUSBIndicator() {
  int x = 50;
  int y = 8;

  tft.fillRect(x, y, 25, 10, ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(x, y + 2);

  if (usbPollingActive) {
    tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
    tft.print("USB");
  }
}

void drawHVIndicator() {
  int x = SCREEN_WIDTH - 45;
  int y = 8;

  tft.fillRect(x, y, 50, 12, ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(x, y + 2);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("HV");

  int squareX = x + 20;
  int squareY = y + 2;

  if (hvState) {
    tft.fillRect(squareX, squareY, 6, 6, ST77XX_GREEN);
    tft.drawRect(squareX, squareY, 6, 6, ST77XX_WHITE);
  } else {
    if (hvBlinkState) {
      tft.fillRect(squareX, squareY, 6, 6, ST77XX_RED);
      tft.drawRect(squareX, squareY, 6, 6, ST77XX_WHITE);
    } else {
      tft.fillRect(squareX, squareY, 6, 6, ST77XX_BLACK);
      tft.drawRect(squareX, squareY, 6, 6, ST77XX_WHITE);
    }
  }
}

void updateUsbPollingStatus() {
  if (currentMode == MODE_MENU) {
    drawUSBIndicator();
  }
}

// ==================== ШИМ СКОРОСТЬ ====================
void setPWMDutyCycle(int percent) {
  int dutyCycle = map(percent, 0, 100, 0, 255);
  analogWrite(SPEED_PIN, dutyCycle);
}

// ==================== ОБРАБОТКА СЧЕТА ====================
void processCounting() {
  if (!countingActive && pumpState) {
    counterValue = 0;
    countingActive = true;
    countingStartTime = millis();
    lastTriggerState = false;
    resultShown = false;
    lastDisplayedCounterValue = -1;
    updateCounterAndTotalDisplay();
  }

  if (countingActive) {
    // Используем миллисекунды для точности (0.1 сек = 100 мс)
    unsigned long requiredTime = (unsigned long)(expositionTime * 1000);
    if (millis() - countingStartTime >= requiredTime) {
      countingActive = false;
      resultShown = true;
      resultDisplayTime = millis();

      totalCounterValue += counterValue;
      saveSettings();
      
      // Принудительно обновляем отображение TOTAL
      forceUpdateTotalDisplay();
      
      return;
    }

    int adcValue = analogRead(COUNT_PIN);
    float voltage = adcValue * (ADC_VOLTAGE / ADC_MAX);
    bool currentState = (voltage < VOLTAGE_THRESHOLD);

    if (currentState == true && lastTriggerState == false) {
      counterValue++;
      updateCounterAndTotalDisplay();
    }

    lastTriggerState = currentState;
  }
}

// ==================== ОБРАБОТКА ЭНКОДЕРА И КНОПКИ (МЕНЮ) ====================
void readEncoderMenu() {
  int encState = digitalRead(ENC_S1);

  if (encState != lastEncState && (millis() - lastDebounceTime) > ENCODER_DEBOUNCE_DELAY) {
    lastDebounceTime = millis();

    int encB = digitalRead(ENC_S2);

    if (encB != encState) {
      encoderCounter++;
      if (encoderCounter >= ENCODER_SENSITIVITY) {
        selectedItem++;
        if (selectedItem >= menuItems) selectedItem = 0;
        encoderCounter = 0;
        needRedrawMenu = true;
      }
    } else {
      encoderCounter--;
      if (encoderCounter <= -ENCODER_SENSITIVITY) {
        selectedItem--;
        if (selectedItem < 0) selectedItem = menuItems - 1;
        encoderCounter = 0;
        needRedrawMenu = true;
      }
    }
  }

  lastEncState = encState;
}

void readButtonMenu() {
  bool currentButtonState = digitalRead(ENC_KEY);

  // Долгое нажатие для сброса общего счетчика
  if (selectedItem == 3 && currentButtonState == LOW && lastButtonState == HIGH) {
    totalResetStartTime = millis();
    totalResetRequested = true;
  }

  if (selectedItem == 3 && totalResetRequested && currentButtonState == LOW) {
    if (millis() - totalResetStartTime >= LONG_PRESS_TIME) {
      totalCounterValue = 0;
      lastTotalValue = 0;
      saveSettings();
      totalResetRequested = false;
      forceUpdateTotalDisplay();
      showMessage("TOTAL RESET!", "Counter cleared");
    }
  }

  if (currentButtonState == HIGH && totalResetRequested) {
    totalResetRequested = false;
    if (selectedItem == 3) {
      needRedrawMenu = true;
    }
  }

  // Короткое нажатие для обычных действий
  if (lastButtonState == HIGH && currentButtonState == LOW && selectedItem != 3) {
    buttonPressTime = millis();
    buttonProcessed = false;
  }

  if (currentButtonState == LOW && !buttonProcessed && (millis() - buttonPressTime) >= LONG_PRESS_TIME && selectedItem != 3) {
    buttonProcessed = true;

    if (selectedItem == 0) {
      togglePump();
    } else if (selectedItem == 1) {
      toggleDir();
    } else if (selectedItem == 2) {
      if (!pumpState) {
        currentMode = MODE_SET_EXPOSITION;
        updateExpositionDisplay();
      } else {
        showMessage("Cannot edit!", "PUMP is ON");
      }
    } else if (selectedItem == 4) {
      currentMode = MODE_SET_SPEED;
      updateSpeedDisplay();
    }
  }

  lastButtonState = currentButtonState;
}

// ==================== НАСТРОЙКА ЭКСПОЗИЦИИ ====================
int findExpoIndex(float value) {
  for (int i = 0; i < expoCount; i++) {
    if (abs(expoValues[i] - value) < 0.01) {
      return i;
    }
  }
  return 4; // Индекс значения 30 по умолчанию
}

void readEncoderExposition() {
  int encState = digitalRead(ENC_S1);
  bool changed = false;

  if (encState != lastEncState && (millis() - lastDebounceTime) > ENCODER_DEBOUNCE_DELAY) {
    lastDebounceTime = millis();

    int encB = digitalRead(ENC_S2);

    if (encB != encState) {
      encoderCounter++;
      if (encoderCounter >= ENCODER_SENSITIVITY) {
        // Увеличение индекса
        if (expoIndex < expoCount - 1) {
          expoIndex++;
          expositionTime = expoValues[expoIndex];
          changed = true;
        }
        encoderCounter = 0;
        if (changed) {
          updateExpositionDisplay();
          saveSettings();
        }
      }
    } else {
      encoderCounter--;
      if (encoderCounter <= -ENCODER_SENSITIVITY) {
        // Уменьшение индекса
        if (expoIndex > 0) {
          expoIndex--;
          expositionTime = expoValues[expoIndex];
          changed = true;
        }
        encoderCounter = 0;
        if (changed) {
          updateExpositionDisplay();
          saveSettings();
        }
      }
    }
  }

  lastEncState = encState;
}

void readButtonExposition() {
  bool currentButtonState = digitalRead(ENC_KEY);

  if (lastButtonState == HIGH && currentButtonState == LOW) {
    buttonPressTime = millis();
    buttonProcessed = false;
  }

  if (currentButtonState == LOW && !buttonProcessed && (millis() - buttonPressTime) >= LONG_PRESS_TIME) {
    buttonProcessed = true;
    currentMode = MODE_MENU;
    needRedrawMenu = true;
  }

  lastButtonState = currentButtonState;
}

// ==================== НАСТРОЙКА СКОРОСТИ ====================
void readEncoderSpeed() {
  int encState = digitalRead(ENC_S1);
  bool changed = false;

  if (encState != lastEncState && (millis() - lastDebounceTime) > ENCODER_DEBOUNCE_DELAY) {
    lastDebounceTime = millis();

    int encB = digitalRead(ENC_S2);

    if (encB != encState) {
      encoderCounter++;
      if (encoderCounter >= ENCODER_SENSITIVITY) {
        if (speedPercent < 100) {
          speedPercent += 10;
          if (speedPercent > 100) speedPercent = 100;
          setPWMDutyCycle(speedPercent);
          changed = true;
        }
        encoderCounter = 0;
        if (changed) {
          updateSpeedDisplay();
          saveSettings();
        }
      }
    } else {
      encoderCounter--;
      if (encoderCounter <= -ENCODER_SENSITIVITY) {
        if (speedPercent > 0) {
          speedPercent -= 10;
          if (speedPercent < 0) speedPercent = 0;
          setPWMDutyCycle(speedPercent);
          changed = true;
        }
        encoderCounter = 0;
        if (changed) {
          updateSpeedDisplay();
          saveSettings();
        }
      }
    }
  }

  lastEncState = encState;
}

void readButtonSpeed() {
  bool currentButtonState = digitalRead(ENC_KEY);

  if (lastButtonState == HIGH && currentButtonState == LOW) {
    buttonPressTime = millis();
    buttonProcessed = false;
  }

  if (currentButtonState == LOW && !buttonProcessed && (millis() - buttonPressTime) >= LONG_PRESS_TIME) {
    buttonProcessed = true;
    currentMode = MODE_MENU;
    needRedrawMenu = true;
  }

  lastButtonState = currentButtonState;
}

// ==================== УПРАВЛЕНИЕ НАСОСОМ И НАПРАВЛЕНИЕМ ====================
void togglePump() {
  pumpState = !pumpState;

  if (pumpState) {
    pumpOnTime = millis();
    pumpTimerActive = true;
    lastTimerUpdate = millis();
    lastDisplayedMinutes = -1;
    lastDisplayedSeconds = -1;
    Serial.println("Pump turned ON");
  } else {
    pumpTimerActive = false;
    countingActive = false;
    counterValue = 0;
    resultShown = false;
    lastDisplayedCounterValue = -1;
    Serial.println("Pump turned OFF");
  }

  needRedrawMenu = true;

  digitalWrite(PUMP_PIN, HIGH);
  delay(500);
  digitalWrite(PUMP_PIN, LOW);
}

void toggleDir() {
  dirState = !dirState;
  needRedrawMenu = true;
  Serial.print("Direction changed to: ");
  Serial.println(dirState ? "LEFT" : "RIGHT");

  digitalWrite(DIR_PIN, HIGH);
  delay(500);
  digitalWrite(DIR_PIN, LOW);
}

// ==================== ФУНКЦИИ ОБНОВЛЕНИЯ ЭКРАНА ====================
void showMessage(String line1, String line2) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextSize(1);
  tft.setCursor(10, 60);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print(line1);
  tft.setCursor(10, 80);
  tft.print(line2);
  delay(1500);
  needRedrawMenu = true;
}

void updatePumpTimerDisplay() {
  if (!pumpTimerActive) return;

  unsigned long elapsed = (millis() - pumpOnTime) / 1000;
  int minutes = elapsed / 60;
  int seconds = elapsed % 60;

  if (minutes == lastDisplayedMinutes && seconds == lastDisplayedSeconds) {
    return;
  }

  lastDisplayedMinutes = minutes;
  lastDisplayedSeconds = seconds;

  // Обновляем только область времени
  tft.fillRect(0, 100, SCREEN_WIDTH, 30, ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(5, 108);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.print("TIME:");

  tft.setTextSize(2);
  tft.setCursor(55, 102);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);

  if (minutes > 0) {
    if (minutes < 10) tft.print(" ");
    tft.print(minutes);
    tft.setTextSize(1);
    tft.setCursor(85, 110);
    tft.print("m");

    tft.setTextSize(2);
    tft.setCursor(100, 102);
    if (seconds < 10) tft.print("0");
    tft.print(seconds);
    tft.setTextSize(1);
    tft.setCursor(125, 110);
    tft.print("s");
  } else {
    if (seconds < 10) tft.print(" ");
    tft.print(seconds);
    tft.setTextSize(1);
    tft.setCursor(85, 110);
    tft.print("sec");
  }
}

void drawMenuTitle() {
  tft.fillRect(0, 0, SCREEN_WIDTH, 22, ST77XX_BLACK);
  tft.setTextSize(2);
  tft.setCursor(2, 3);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.print("MENU");
  tft.drawLine(2, 20, SCREEN_WIDTH - 2, 20, ST77XX_CYAN);

  drawUSBIndicator();
  drawHVIndicator();
}

void updateCounterAndTotalDisplay() {
  if (currentMode != MODE_MENU) return;

  int y4 = 74;
  String countDisplay;

  if (resultShown) {
    countDisplay = "COUNTER:" + String(counterValue);
  } else if (!pumpState) {
    countDisplay = "COUNTER:OFF";
  } else if (countingActive) {
    countDisplay = "COUNTER:" + String(counterValue);
  } else {
    countDisplay = "COUNTER:0";
  }

  String totalDisplay = "TOTAL:" + String(totalCounterValue);

  if (selectedItem == 3) {
    // Если выбран пункт TOTAL, перерисовываем оба с синим фоном
    tft.fillRect(1, y4 - 3, 125, 14, ST77XX_BLUE);
    tft.setCursor(10, y4);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print(countDisplay);
    tft.setCursor(85, y4);
    tft.print(totalDisplay);
    lastDisplayedCounterValue = counterValue;
    lastTotalValue = totalCounterValue;
  } else {
    // Обновляем счетчик если изменился
    if (lastDisplayedCounterValue != counterValue) {
      tft.fillRect(10, y4 - 3, 75, 14, ST77XX_BLACK);
      tft.setCursor(10, y4);
      tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
      tft.print(countDisplay);
      lastDisplayedCounterValue = counterValue;
    }

    // Всегда обновляем TOTAL если он изменился
    if (lastTotalValue != totalCounterValue) {
      tft.fillRect(85, y4 - 3, 45, 14, ST77XX_BLACK);
      tft.setCursor(85, y4);
      tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
      tft.print(totalDisplay);
      lastTotalValue = totalCounterValue;
    }
  }
}

void forceUpdateTotalDisplay() {
  if (currentMode != MODE_MENU) return;
  
  int y4 = 74;
  String totalDisplay = "TOTAL:" + String(totalCounterValue);
  
  if (selectedItem == 3) {
    // Если выбран пункт TOTAL, перерисовываем оба с синим фоном
    String countDisplay;
    if (resultShown) {
      countDisplay = "COUNTER:" + String(counterValue);
    } else if (!pumpState) {
      countDisplay = "COUNTER:OFF";
    } else if (countingActive) {
      countDisplay = "COUNTER:" + String(counterValue);
    } else {
      countDisplay = "COUNTER:0";
    }
    
    tft.fillRect(1, y4 - 3, 125, 14, ST77XX_BLUE);
    tft.setCursor(10, y4);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print(countDisplay);
    tft.setCursor(85, y4);
    tft.print(totalDisplay);
    lastDisplayedCounterValue = counterValue;
  } else {
    // Перерисовываем только TOTAL
    tft.fillRect(85, y4 - 3, 45, 14, ST77XX_BLACK);
    tft.setCursor(85, y4);
    tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
    tft.print(totalDisplay);
  }
  
  lastTotalValue = totalCounterValue;
}

void updateDynamicValuesOnly() {
  // Обновляем таймер насоса
  if (pumpTimerActive && pumpState) {
    updatePumpTimerDisplay();
  }

  // Обновляем счетчики
  updateCounterAndTotalDisplay();
}

void fullRedraw() {
  tft.fillScreen(ST77XX_BLACK);

  drawMenuTitle();

  tft.setTextSize(1);

  // PUMP
  int y1 = 26;
  if (selectedItem == 0) {
    tft.fillRect(1, y1 - 3, 85, 14, ST77XX_BLUE);
    tft.setCursor(10, y1);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print(pumpState ? "PUMP:ON" : "PUMP:OFF");
  } else {
    tft.setCursor(10, y1);
    tft.setTextColor(pumpState ? ST77XX_GREEN : ST77XX_RED, ST77XX_BLACK);
    tft.print(pumpState ? "PUMP:ON" : "PUMP:OFF");
  }

  // DIRECTION
  int y2 = 42;
  if (selectedItem == 1) {
    tft.fillRect(1, y2 - 3, 105, 14, ST77XX_BLUE);
    tft.setCursor(10, y2);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print(dirState ? "DIRECTION:LEFT" : "DIRECTION:RIGHT");
  } else {
    tft.setCursor(10, y2);
    tft.setTextColor(dirState ? ST77XX_GREEN : ST77XX_RED, ST77XX_BLACK);
    tft.print(dirState ? "DIRECTION:LEFT" : "DIRECTION:RIGHT");
  }

  // EXPOSITION
  int y3 = 58;
  String expoStr;
  if (expositionTime == (int)expositionTime) {
    expoStr = String((int)expositionTime);
  } else {
    expoStr = String(expositionTime, 1);
  }
  
  if (selectedItem == 2) {
    tft.fillRect(1, y3 - 3, 105, 14, ST77XX_BLUE);
    tft.setCursor(10, y3);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print("EXPOSITION:" + expoStr + "s");
  } else {
    tft.setCursor(10, y3);
    if (pumpState) {
      tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
      tft.print("EXPOSITION:" + expoStr + "s");
    } else {
      tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
      tft.print("EXPOSITION:" + expoStr + "s");
    }
  }

  // COUNTER & TOTAL
  int y4 = 74;
  String countDisplay;

  if (resultShown) {
    countDisplay = "COUNTER:" + String(counterValue);
  } else if (!pumpState) {
    countDisplay = "COUNTER:OFF";
  } else if (countingActive) {
    countDisplay = "COUNTER:" + String(counterValue);
  } else {
    countDisplay = "COUNTER:0";
  }

  String totalDisplay = "TOTAL:" + String(totalCounterValue);

  if (selectedItem == 3) {
    tft.fillRect(1, y4 - 3, 125, 14, ST77XX_BLUE);
    tft.setCursor(10, y4);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print(countDisplay);
    tft.setCursor(85, y4);
    tft.print(totalDisplay);
  } else {
    tft.setCursor(10, y4);
    tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
    tft.print(countDisplay);
    tft.setCursor(85, y4);
    tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
    tft.print(totalDisplay);
  }

  lastDisplayedCounterValue = counterValue;
  lastTotalValue = totalCounterValue;

  // SPEED
  int y5 = 90;
  if (selectedItem == 4) {
    tft.fillRect(1, y5 - 3, 100, 14, ST77XX_BLUE);
    tft.setCursor(10, y5);
    tft.setTextColor(ST77XX_WHITE, ST77XX_BLUE);
    tft.print("SPEED:" + String(speedPercent) + "%");
  } else {
    tft.setCursor(10, y5);
    tft.setTextColor(ST77XX_MAGENTA, ST77XX_BLACK);
    tft.print("SPEED:" + String(speedPercent) + "%");
  }

  // Подсказки внизу
  tft.setTextSize(1);
  tft.drawRect(1, 140, 126, 18, ST77XX_BLUE);
  tft.setCursor(4, 144);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Rotate:Sel");
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print(" ");
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Hold:Act");

  if (selectedItem == 2 && pumpState) {
    tft.setCursor(4, 130);
    tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
    tft.print("Locked: PUMP ON");
  }

  // Обновляем переменные для отслеживания
  lastPumpStateForRedraw = pumpState;
  lastDirStateForRedraw = dirState;
  lastExpositionValue = expositionTime;
  lastSpeedValue = speedPercent;
}

void updateExpositionDisplay() {
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(2, 3);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.print("SET EXPOSITION");
  tft.drawLine(2, 12, SCREEN_WIDTH - 2, 12, ST77XX_CYAN);

  tft.setTextSize(3);
  tft.setCursor(10, 40);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);

  // Форматируем вывод: если целое число - без десятичной точки
  if (expositionTime == (int)expositionTime) {
    if (expositionTime < 100) tft.print(" ");
    tft.print((int)expositionTime);
  } else {
    tft.print(expositionTime, 1);
  }

  tft.setTextSize(1);
  tft.setCursor(70, 52);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("seconds");

  // Рисуем шкалу
  int barWidth;
  if (expositionTime <= 1) {
    barWidth = map(expositionTime * 100, 10, 100, 5, 20);
    if (barWidth < 5) barWidth = 5;
  } else {
    barWidth = map(expositionTime, 10, 120, 20, 100);
  }
  tft.fillRect(5, 75, barWidth, 6, ST77XX_GREEN);
  tft.drawRect(5, 75, 100, 6, ST77XX_WHITE);

  // Рисуем метки на шкале
  for (float i = 0.1; i <= 120; i *= 10) {
    int x;
    if (i <= 1) {
      x = map(i * 100, 10, 100, 5, 20);
    } else {
      x = map(i, 10, 120, 20, 105);
    }
    if (x >= 5 && x <= 105) {
      tft.drawLine(x, 75, x, 81, ST77XX_WHITE);
    }
  }

  tft.setCursor(5, 90);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("0.1s");
  tft.setCursor(95, 90);
  tft.print("120s");

  tft.setCursor(5, 120);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("Hold to exit");

  tft.drawRect(1, 140, 126, 18, ST77XX_BLUE);
  tft.setCursor(4, 144);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Rotate:Change");
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print(" ");
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Hold:Back");
}

void updateSpeedDisplay() {
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setCursor(2, 3);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.print("SET SPEED");
  tft.drawLine(2, 12, SCREEN_WIDTH - 2, 12, ST77XX_CYAN);

  tft.setTextSize(3);
  tft.setCursor(25, 40);
  tft.setTextColor(ST77XX_MAGENTA, ST77XX_BLACK);

  if (speedPercent < 100) tft.print(" ");
  if (speedPercent < 10) tft.print(" ");
  tft.print(speedPercent);

  tft.setTextSize(1);
  tft.setCursor(85, 52);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("%");

  int barWidth = map(speedPercent, 0, 100, 10, 100);
  tft.fillRect(5, 75, barWidth, 12, ST77XX_MAGENTA);
  tft.drawRect(5, 75, 105, 12, ST77XX_WHITE);

  for (int i = 10; i <= 100; i += 10) {
    int x = map(i, 0, 100, 5, 110);
    tft.drawLine(x, 75, x, 87, ST77XX_WHITE);
  }

  tft.setCursor(5, 95);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("0%");
  tft.setCursor(90, 95);
  tft.print("100%");

  tft.setCursor(5, 120);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print("Hold to exit");

  tft.drawRect(1, 140, 126, 18, ST77XX_BLUE);
  tft.setCursor(4, 144);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Rotate:Change");
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.print(" ");
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.print("Hold:Back");
}