﻿namespace Flow_Counter_Utility
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.btnDir = new System.Windows.Forms.Button();
            this.btnConection = new System.Windows.Forms.Button();
            this.btnPump = new System.Windows.Forms.Button();
            this.cmbExp = new System.Windows.Forms.ComboBox();
            this.cmbSpeed = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblConnectionStatus = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblBackgroundRadiation = new System.Windows.Forms.Label();
            this.btnBKG = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblHV = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblCounter = new System.Windows.Forms.Label();
            this.lblDir = new System.Windows.Forms.Label();
            this.lblPump = new System.Windows.Forms.Label();
            this.btnSpeed = new System.Windows.Forms.Button();
            this.btnResetCounter = new System.Windows.Forms.Button();
            this.btnExp = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblTimeRecord = new System.Windows.Forms.Label();
            this.btnRecordStop = new System.Windows.Forms.Button();
            this.btnRecordStart = new System.Windows.Forms.Button();
            this.chartIMPtime = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label7 = new System.Windows.Forms.Label();
            this.btnCalcLiquid = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lblCalcLiquid = new System.Windows.Forms.Label();
            this.btnHelp = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartIMPtime)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDir
            // 
            this.btnDir.Location = new System.Drawing.Point(255, 43);
            this.btnDir.Name = "btnDir";
            this.btnDir.Size = new System.Drawing.Size(86, 23);
            this.btnDir.TabIndex = 0;
            this.btnDir.Text = "Переключить";
            this.btnDir.UseVisualStyleBackColor = true;
            // 
            // btnConection
            // 
            this.btnConection.BackColor = System.Drawing.SystemColors.Control;
            this.btnConection.Location = new System.Drawing.Point(14, 19);
            this.btnConection.Name = "btnConection";
            this.btnConection.Size = new System.Drawing.Size(117, 23);
            this.btnConection.TabIndex = 1;
            this.btnConection.Text = "Поиск устройства";
            this.btnConection.UseVisualStyleBackColor = false;
            // 
            // btnPump
            // 
            this.btnPump.BackColor = System.Drawing.SystemColors.Control;
            this.btnPump.Location = new System.Drawing.Point(255, 14);
            this.btnPump.Name = "btnPump";
            this.btnPump.Size = new System.Drawing.Size(86, 23);
            this.btnPump.TabIndex = 3;
            this.btnPump.Text = "Переключить";
            this.btnPump.UseVisualStyleBackColor = true;
            // 
            // cmbExp
            // 
            this.cmbExp.FormattingEnabled = true;
            this.cmbExp.Location = new System.Drawing.Point(5, 74);
            this.cmbExp.Name = "cmbExp";
            this.cmbExp.Size = new System.Drawing.Size(121, 21);
            this.cmbExp.TabIndex = 5;
            // 
            // cmbSpeed
            // 
            this.cmbSpeed.FormattingEnabled = true;
            this.cmbSpeed.Location = new System.Drawing.Point(5, 161);
            this.cmbSpeed.Name = "cmbSpeed";
            this.cmbSpeed.Size = new System.Drawing.Size(121, 21);
            this.cmbSpeed.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblConnectionStatus);
            this.groupBox1.Controls.Add(this.btnConection);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(204, 80);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Подключение к COM";
            // 
            // lblConnectionStatus
            // 
            this.lblConnectionStatus.AutoSize = true;
            this.lblConnectionStatus.Location = new System.Drawing.Point(10, 55);
            this.lblConnectionStatus.Name = "lblConnectionStatus";
            this.lblConnectionStatus.Size = new System.Drawing.Size(97, 13);
            this.lblConnectionStatus.TabIndex = 5;
            this.lblConnectionStatus.Text = "Статус: Отключен";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblBackgroundRadiation);
            this.groupBox2.Controls.Add(this.btnBKG);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lblHV);
            this.groupBox2.Controls.Add(this.lblTime);
            this.groupBox2.Controls.Add(this.lblCounter);
            this.groupBox2.Controls.Add(this.lblDir);
            this.groupBox2.Controls.Add(this.lblPump);
            this.groupBox2.Controls.Add(this.cmbSpeed);
            this.groupBox2.Controls.Add(this.btnSpeed);
            this.groupBox2.Controls.Add(this.cmbExp);
            this.groupBox2.Controls.Add(this.btnResetCounter);
            this.groupBox2.Controls.Add(this.btnExp);
            this.groupBox2.Controls.Add(this.btnPump);
            this.groupBox2.Controls.Add(this.btnDir);
            this.groupBox2.Location = new System.Drawing.Point(13, 98);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(347, 248);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Управление";
            // 
            // lblBackgroundRadiation
            // 
            this.lblBackgroundRadiation.AutoSize = true;
            this.lblBackgroundRadiation.Location = new System.Drawing.Point(9, 106);
            this.lblBackgroundRadiation.Name = "lblBackgroundRadiation";
            this.lblBackgroundRadiation.Size = new System.Drawing.Size(66, 13);
            this.lblBackgroundRadiation.TabIndex = 17;
            this.lblBackgroundRadiation.Text = "--- Имп/мин";
            // 
            // btnBKG
            // 
            this.btnBKG.Location = new System.Drawing.Point(255, 101);
            this.btnBKG.Name = "btnBKG";
            this.btnBKG.Size = new System.Drawing.Size(86, 23);
            this.btnBKG.TabIndex = 12;
            this.btnBKG.Text = "Измерить";
            this.btnBKG.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(165, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Фон, имп/мин";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(180, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Скорость,%";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(186, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Импульсы";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(154, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Экспозиция, сек";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(152, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Направление, l/0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(166, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Состояние, l/0";
            // 
            // lblHV
            // 
            this.lblHV.AutoSize = true;
            this.lblHV.Location = new System.Drawing.Point(10, 222);
            this.lblHV.Name = "lblHV";
            this.lblHV.Size = new System.Drawing.Size(124, 13);
            this.lblHV.TabIndex = 12;
            this.lblHV.Text = "Напряжение СБМ-20:---";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(10, 199);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(92, 13);
            this.lblTime.TabIndex = 11;
            this.lblTime.Text = "Время работы:---";
            // 
            // lblCounter
            // 
            this.lblCounter.AutoSize = true;
            this.lblCounter.Location = new System.Drawing.Point(9, 135);
            this.lblCounter.Name = "lblCounter";
            this.lblCounter.Size = new System.Drawing.Size(119, 13);
            this.lblCounter.TabIndex = 9;
            this.lblCounter.Text = "Текущий:--- | Общий:---";
            // 
            // lblDir
            // 
            this.lblDir.AutoSize = true;
            this.lblDir.Location = new System.Drawing.Point(9, 48);
            this.lblDir.Name = "lblDir";
            this.lblDir.Size = new System.Drawing.Size(44, 13);
            this.lblDir.TabIndex = 10;
            this.lblDir.Text = "ВЛЕВО";
            // 
            // lblPump
            // 
            this.lblPump.AutoSize = true;
            this.lblPump.Location = new System.Drawing.Point(9, 19);
            this.lblPump.Name = "lblPump";
            this.lblPump.Size = new System.Drawing.Size(71, 13);
            this.lblPump.TabIndex = 9;
            this.lblPump.Text = "ВЫКЛЮЧЕН";
            // 
            // btnSpeed
            // 
            this.btnSpeed.Location = new System.Drawing.Point(255, 159);
            this.btnSpeed.Name = "btnSpeed";
            this.btnSpeed.Size = new System.Drawing.Size(86, 23);
            this.btnSpeed.TabIndex = 9;
            this.btnSpeed.Text = "Переключить";
            this.btnSpeed.UseVisualStyleBackColor = true;
            // 
            // btnResetCounter
            // 
            this.btnResetCounter.Location = new System.Drawing.Point(255, 130);
            this.btnResetCounter.Name = "btnResetCounter";
            this.btnResetCounter.Size = new System.Drawing.Size(86, 23);
            this.btnResetCounter.TabIndex = 9;
            this.btnResetCounter.Text = "Сброс";
            this.btnResetCounter.UseVisualStyleBackColor = true;
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(255, 72);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(86, 23);
            this.btnExp.TabIndex = 9;
            this.btnExp.Text = "Переключить";
            this.btnExp.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblTimeRecord);
            this.groupBox4.Controls.Add(this.btnRecordStop);
            this.groupBox4.Controls.Add(this.btnRecordStart);
            this.groupBox4.Location = new System.Drawing.Point(13, 415);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(347, 80);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Запись в csv";
            // 
            // lblTimeRecord
            // 
            this.lblTimeRecord.AutoSize = true;
            this.lblTimeRecord.Location = new System.Drawing.Point(10, 55);
            this.lblTimeRecord.Name = "lblTimeRecord";
            this.lblTimeRecord.Size = new System.Drawing.Size(114, 13);
            this.lblTimeRecord.TabIndex = 2;
            this.lblTimeRecord.Text = "Последняя запись:---";
            // 
            // btnRecordStop
            // 
            this.btnRecordStop.Location = new System.Drawing.Point(123, 19);
            this.btnRecordStop.Name = "btnRecordStop";
            this.btnRecordStop.Size = new System.Drawing.Size(86, 23);
            this.btnRecordStop.TabIndex = 1;
            this.btnRecordStop.Text = "Остановить";
            this.btnRecordStop.UseVisualStyleBackColor = true;
            // 
            // btnRecordStart
            // 
            this.btnRecordStart.BackColor = System.Drawing.SystemColors.Control;
            this.btnRecordStart.Location = new System.Drawing.Point(13, 19);
            this.btnRecordStart.Name = "btnRecordStart";
            this.btnRecordStart.Size = new System.Drawing.Size(95, 23);
            this.btnRecordStart.TabIndex = 0;
            this.btnRecordStart.Text = "Начать запись";
            this.btnRecordStart.UseVisualStyleBackColor = false;
            // 
            // chartIMPtime
            // 
            this.chartIMPtime.BackColor = System.Drawing.Color.WhiteSmoke;
            chartArea4.Name = "ChartArea1";
            this.chartIMPtime.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.chartIMPtime.Legends.Add(legend4);
            this.chartIMPtime.Location = new System.Drawing.Point(366, 28);
            this.chartIMPtime.Name = "chartIMPtime";
            this.chartIMPtime.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Импульсы";
            this.chartIMPtime.Series.Add(series4);
            this.chartIMPtime.Size = new System.Drawing.Size(606, 438);
            this.chartIMPtime.TabIndex = 10;
            this.chartIMPtime.Text = "chart1";
            this.chartIMPtime.Click += new System.EventHandler(this.chartIMPtime_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(363, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(165, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "График импульсов по времени";
            // 
            // btnCalcLiquid
            // 
            this.btnCalcLiquid.Location = new System.Drawing.Point(255, 19);
            this.btnCalcLiquid.Name = "btnCalcLiquid";
            this.btnCalcLiquid.Size = new System.Drawing.Size(86, 23);
            this.btnCalcLiquid.TabIndex = 14;
            this.btnCalcLiquid.Text = "Начать счет";
            this.btnCalcLiquid.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.lblCalcLiquid);
            this.groupBox3.Controls.Add(this.btnCalcLiquid);
            this.groupBox3.Location = new System.Drawing.Point(13, 352);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(347, 57);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Счет прокаченной жидкости";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(184, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Объем, мл";
            // 
            // lblCalcLiquid
            // 
            this.lblCalcLiquid.AutoSize = true;
            this.lblCalcLiquid.Location = new System.Drawing.Point(10, 24);
            this.lblCalcLiquid.Name = "lblCalcLiquid";
            this.lblCalcLiquid.Size = new System.Drawing.Size(74, 13);
            this.lblCalcLiquid.TabIndex = 15;
            this.lblCalcLiquid.Text = "Прокачено:---";
            // 
            // btnHelp
            // 
            this.btnHelp.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnHelp.Location = new System.Drawing.Point(947, 472);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(25, 25);
            this.btnHelp.TabIndex = 16;
            this.btnHelp.Text = "❓";
            this.btnHelp.UseVisualStyleBackColor = false;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 505);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.chartIMPtime);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Утилита управления v1.5";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartIMPtime)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDir;
        private System.Windows.Forms.Button btnConection;
        private System.Windows.Forms.Button btnPump;
        private System.Windows.Forms.ComboBox cmbExp;
        private System.Windows.Forms.ComboBox cmbSpeed;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblCounter;
        private System.Windows.Forms.Label lblDir;
        private System.Windows.Forms.Label lblPump;
        private System.Windows.Forms.Button btnSpeed;
        private System.Windows.Forms.Button btnResetCounter;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnRecordStop;
        private System.Windows.Forms.Button btnRecordStart;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblHV;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartIMPtime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblBackgroundRadiation;
        private System.Windows.Forms.Button btnBKG;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblConnectionStatus;
        private System.Windows.Forms.Label lblTimeRecord;
        private System.Windows.Forms.Button btnCalcLiquid;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblCalcLiquid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnHelp;
    }
}

