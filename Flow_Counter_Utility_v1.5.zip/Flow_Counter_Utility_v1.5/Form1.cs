﻿//Версия 1.5 для ПК
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO.Ports;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Flow_Counter_Utility
{
    public partial class Form1 : Form
    {
        private SerialPort _serialPort;
        private bool _isConnected = false;
        private readonly object _serialLock = new object();
        private CancellationTokenSource _pollingCancellation;
        private Task _pollingTask;
        private float _lastHVVoltage = 0f;
        private int _backgroundValue = 0;
        private bool _isBackgroundMeasuring = false;

        // Данные графика
        private long _lastTotalValue = 0;
        private DateTime _lastChartUpdate = DateTime.Now;
        private bool _isFirstPoint = true;
        private double _lastExpoTime = 30.0;
        private DateTime _pumpStartTime = DateTime.Now;

        // Таймеры блокировки комбобоксов (явно указываем System.Windows.Forms.Timer)
        private readonly System.Windows.Forms.Timer _expComboBoxTimer = new System.Windows.Forms.Timer();
        private readonly System.Windows.Forms.Timer _speedComboBoxTimer = new System.Windows.Forms.Timer();
        private DateTime _expComboBoxLockUntil = DateTime.MinValue;
        private DateTime _speedComboBoxLockUntil = DateTime.MinValue;
        private const int LOCK_DURATION_SECONDS = 10;

        // Словарь для отображения скорости
        private readonly Dictionary<int, string> _speedDisplayMap = new Dictionary<int, string>
        {
            { 0, "0% 0 rpm" },
            { 10, "10% 27 rpm" },
            { 20, "20% 57 rpm" },
            { 30, "30% 86 rpm" },
            { 40, "40% 115 rpm" },
            { 50, "50% 144 rpm" },
            { 60, "60% 174 rpm" },
            { 70, "70% 203 rpm" },
            { 80, "80% 232 rpm" },
            { 90, "90% 261 rpm" },
            { 100, "100% 292 rpm" }
        };

        // Словарь расхода жидкости (мл/мин) для каждой скорости
        private readonly Dictionary<int, double> _flowRateMap = new Dictionary<int, double>
        {
            { 0, 0.0 },
            { 10, 3.085 },
            { 20, 6.67 },
            { 30, 10.0 },
            { 40, 13.47 },
            { 50, 16.95 },
            { 60, 20.375 },
            { 70, 23.995 },
            { 80, 27.09 },
            { 90, 30.78 },
            { 100, 34.4 }
        };

        // Переменные для счета жидкости
        private double _liquidVolume = 0.0;
        private bool _liquidCounting = false;
        private DateTime _liquidLastUpdate = DateTime.Now;
        private readonly System.Windows.Forms.Timer _liquidTimer = new System.Windows.Forms.Timer();

        // CSV запись
        private bool _isRecording = false;
        private DateTime _recordingStartTime;
        private Stopwatch _recordingStopwatch = new Stopwatch();
        private readonly List<string> _csvRecords = new List<string>();
        private string _csvFilePath = string.Empty;
        private int _recordCounter = 0;

        // Отмена измерения фона
        private CancellationTokenSource _backgroundCancellation;

        public Form1()
        {
            InitializeComponent();
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            // Привязка событий
            btnConection.Click += btnConection_Click;
            btnPump.Click += btnPump_Click;
            btnDir.Click += btnDir_Click;
            btnResetCounter.Click += btnResetCounter_Click;
            btnExp.Click += btnExp_Click;
            btnBKG.Click += btnBKG_Click;
            btnSpeed.Click += btnSpeed_Click;
            btnRecordStart.Click += btnRecordStart_Click;
            btnRecordStop.Click += btnRecordStop_Click;
            btnCalcLiquid.Click += btnCalcLiquid_Click;
            btnHelp.Click += btnHelp_Click;
            FormClosing += Form1_FormClosing;

            cmbExp.SelectedIndexChanged += cmbExp_SelectedIndexChanged;
            cmbSpeed.SelectedIndexChanged += cmbSpeed_SelectedIndexChanged;

            // Настройка таймеров блокировки
            _expComboBoxTimer.Interval = 1000;
            _expComboBoxTimer.Tick += ExpComboBoxTimer_Tick;
            _speedComboBoxTimer.Interval = 1000;
            _speedComboBoxTimer.Tick += SpeedComboBoxTimer_Tick;

            // Настройка таймера для счета жидкости
            _liquidTimer.Interval = 1000;
            _liquidTimer.Tick += LiquidTimer_Tick;

            FillComboBoxes();
            SetupChart();

            btnRecordStart.Enabled = false;
            btnRecordStart.BackColor = Color.LightGray;
            btnRecordStop.Enabled = false;
            btnRecordStop.BackColor = Color.LightGray;

            // Инициализируем кнопку счета жидкости
            btnCalcLiquid.Text = "Начать счет";
            btnCalcLiquid.BackColor = SystemColors.Control;
            lblCalcLiquid.Text = "0.00 мл";

            SetAllControlsEnabled(false);
        }

        // ===== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ =====

        private void ExpComboBoxTimer_Tick(object sender, EventArgs e)
        {
            if (DateTime.Now >= _expComboBoxLockUntil)
            {
                _expComboBoxTimer.Stop();
                btnExp.BackColor = SystemColors.Control;
                // Сбрасываем блокировку для комбобокса
                _expComboBoxLockUntil = DateTime.MinValue;
            }
        }

        private void SpeedComboBoxTimer_Tick(object sender, EventArgs e)
        {
            if (DateTime.Now >= _speedComboBoxLockUntil)
            {
                _speedComboBoxTimer.Stop();
                btnSpeed.BackColor = SystemColors.Control;
                // Сбрасываем блокировку для комбобокса
                _speedComboBoxLockUntil = DateTime.MinValue;
            }
        }

        private void LiquidTimer_Tick(object sender, EventArgs e)
        {
            if (!_liquidCounting) return;

            // Проверяем, включен ли насос
            if (lblPump.Text != "ВКЛЮЧЕН")
            {
                // Насос остановлен - автоматически останавливаем счет
                StopLiquidCounting(false);
                return;
            }

            // Получаем текущую скорость
            int currentSpeed = GetCurrentSpeed();

            // Получаем расход для текущей скорости
            double flowRate = _flowRateMap.TryGetValue(currentSpeed, out double rate) ? rate : 0.0;

            // Рассчитываем прошедшее время в минутах
            DateTime now = DateTime.Now;
            double elapsedMinutes = (now - _liquidLastUpdate).TotalMinutes;

            if (elapsedMinutes > 0)
            {
                // Рассчитываем добавленный объем
                double addedVolume = elapsedMinutes * flowRate;
                _liquidVolume += addedVolume;

                // Обновляем отображение
                UpdateLiquidDisplay();
            }

            _liquidLastUpdate = now;
        }

        private int GetCurrentSpeed()
        {
            if (cmbSpeed.SelectedItem == null) return 0;

            string selectedText = cmbSpeed.SelectedItem.ToString();
            return GetSpeedValueFromDisplay(selectedText);
        }

        private void UpdateLiquidDisplay()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(UpdateLiquidDisplay));
                return;
            }

            lblCalcLiquid.Text = $"{_liquidVolume:F2} мл";
        }

        private void StartLiquidCounting()
        {
            if (_liquidCounting) return;

            // Проверяем, включен ли насос
            if (lblPump.Text != "ВКЛЮЧЕН")
            {
                // Насос выключен - счет не начинаем, но и не показываем ошибку
                return;
            }

            _liquidCounting = true;
            _liquidLastUpdate = DateTime.Now;
            _liquidTimer.Start();

            // Меняем кнопку на "Стоп"
            if (InvokeRequired)
            {
                Invoke(new Action(() =>
                {
                    btnCalcLiquid.Text = "Стоп";
                }));
            }
            else
            {
                btnCalcLiquid.Text = "Стоп";
            }
        }

        private void StopLiquidCounting(bool resetButton = true)
        {
            if (!_liquidCounting) return;

            _liquidCounting = false;
            _liquidTimer.Stop();

            if (InvokeRequired)
            {
                Invoke(new Action(() =>
                {
                    if (resetButton)
                    {
                        btnCalcLiquid.Text = "Сброс";
                        btnCalcLiquid.BackColor = Color.Red;
                    }
                }));
            }
            else
            {
                if (resetButton)
                {
                    btnCalcLiquid.Text = "Сброс";
                    btnCalcLiquid.BackColor = Color.Red;
                }
            }
        }

        private void ResetLiquidCounter()
        {
            _liquidVolume = 0.0;
            UpdateLiquidDisplay();

            if (InvokeRequired)
            {
                Invoke(new Action(() =>
                {
                    btnCalcLiquid.Text = "Начать счет";
                    btnCalcLiquid.BackColor = SystemColors.Control;
                }));
            }
            else
            {
                btnCalcLiquid.Text = "Начать счет";
                btnCalcLiquid.BackColor = SystemColors.Control;
            }
        }

        private void FillComboBoxes()
        {
            // Заполняем Exp
            cmbExp.Items.AddRange(new object[] { "0.5", "1", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120" });
            cmbExp.SelectedIndex = 4;

            // Заполняем Speed с отображением
            cmbSpeed.Items.Clear();
            for (int i = 0; i <= 100; i += 10)
            {
                cmbSpeed.Items.Add(_speedDisplayMap[i]);
            }
            cmbSpeed.SelectedIndex = 0;
        }

        private int GetSpeedValueFromDisplay(string displayText)
        {
            // Извлекаем число до % 
            // Например из "10% 27rpm" получаем 10
            if (string.IsNullOrEmpty(displayText)) return 0;

            int percentIndex = displayText.IndexOf('%');
            if (percentIndex > 0)
            {
                string numberPart = displayText.Substring(0, percentIndex).Trim();
                if (int.TryParse(numberPart, out int value))
                    return value;
            }
            return 0;
        }

        private void SetupChart()
        {
            chartIMPtime.Series.Clear();
            var series = new Series("Импульсы")
            {
                ChartType = SeriesChartType.Line,
                Color = Color.Green,
                BorderWidth = 3,
                MarkerStyle = MarkerStyle.Circle,
                MarkerSize = 6,
                MarkerColor = Color.Blue
            };
            chartIMPtime.Series.Add(series);
            chartIMPtime.Legends[0].Enabled = false;

            var area = chartIMPtime.ChartAreas[0];
            area.AxisX.Title = "Время, мин";
            area.AxisX.LabelStyle.Format = "F1";
            area.AxisX.Interval = 0.5;
            area.AxisX.MajorGrid.LineColor = Color.LightGray;
            area.AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;

            area.AxisY.Title = "Импульсы";
            area.AxisY.Minimum = 0;
            area.AxisY.Interval = 50;
            area.AxisY.MajorGrid.LineColor = Color.LightGray;
            area.AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
        }

        private void SetAllControlsEnabled(bool enabled)
        {
            bool pumpOn = lblPump.Text == "ВКЛЮЧЕН";
            bool backgroundMeasuring = _isBackgroundMeasuring;

            btnPump.Enabled = enabled && !backgroundMeasuring;
            btnDir.Enabled = enabled && !backgroundMeasuring;
            btnResetCounter.Enabled = enabled && !backgroundMeasuring;
            btnExp.Enabled = enabled && !backgroundMeasuring && !pumpOn;
            btnBKG.Enabled = enabled && !pumpOn;
            btnSpeed.Enabled = enabled && !backgroundMeasuring;
            btnCalcLiquid.Enabled = enabled;

            cmbExp.Enabled = enabled && !backgroundMeasuring && !pumpOn;
            cmbSpeed.Enabled = enabled && !backgroundMeasuring;

            btnRecordStart.Enabled = enabled && !_isRecording;
            btnRecordStop.Enabled = enabled && _isRecording;
            btnHelp.Enabled = true;

            // Управление цветом кнопок записи
            if (enabled)
            {
                btnRecordStart.BackColor = _isRecording ? Color.LightGray : Color.LightGreen;
                btnRecordStop.BackColor = _isRecording ? Color.OrangeRed : Color.LightGray;
                UpdateButtonsAvailability();
            }
            else
            {
                btnRecordStart.BackColor = Color.LightGray;
                btnRecordStop.BackColor = Color.LightGray;
            }
        }

        private void LockControlsDuringBackgroundMeasurement()
        {
            SetAllControlsEnabled(false);
            btnBKG.Enabled = true;
            btnBKG.BackColor = Color.OrangeRed;
            btnBKG.Text = "Остановить";
        }

        private void UnlockControlsAfterBackgroundMeasurement()
        {
            SetAllControlsEnabled(true);
            btnBKG.BackColor = SystemColors.Control;
            btnBKG.Text = "Измерить фон";
            btnBKG.Enabled = true;
        }

        private void UpdateButtonsAvailability()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(UpdateButtonsAvailability));
                return;
            }

            bool isPumpOn = lblPump.Text == "ВКЛЮЧЕН";
            bool connected = _isConnected;

            btnExp.Enabled = connected && !isPumpOn && !_isBackgroundMeasuring;
            btnBKG.Enabled = connected && !isPumpOn;
            btnPump.Enabled = connected && !_isBackgroundMeasuring;
            btnSpeed.Enabled = connected && !_isBackgroundMeasuring;
            btnDir.Enabled = connected && !_isBackgroundMeasuring;
            btnResetCounter.Enabled = connected && !_isBackgroundMeasuring;
            btnCalcLiquid.Enabled = connected;

            btnRecordStart.Enabled = connected && !_isRecording;
            btnRecordStop.Enabled = connected && _isRecording;
        }

        private void ClearDisplay()
        {
            lblPump.Text = "ВЫКЛЮЧЕН";
            lblPump.ForeColor = Color.Gray;
            lblDir.Text = "ВПРАВО";
            lblCounter.Text = "Текущий: 0 | Общий: 0";
            lblHV.Text = "Напряжение СБМ-20: ---";
            lblHV.ForeColor = Color.Gray;
            lblTime.Text = "Время работы: ---";
            lblBackgroundRadiation.Text = "--- Имп/мин";

            SetAllControlsEnabled(false);
        }

        private void ResetChart()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(ResetChart));
                return;
            }

            chartIMPtime.Series["Импульсы"].Points.Clear();
            _lastTotalValue = 0;
            _lastChartUpdate = DateTime.Now;
            _isFirstPoint = true;
            _pumpStartTime = DateTime.Now;

            chartIMPtime.ChartAreas[0].AxisY.Maximum = double.NaN;
            chartIMPtime.ChartAreas[0].AxisY.Minimum = 0;
        }

        // ===== ОБРАБОТЧИКИ СОБЫТИЙ КОМБОБОКСОВ =====

        private void cmbExp_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!cmbExp.Focused) return;
            _expComboBoxLockUntil = DateTime.Now.AddSeconds(LOCK_DURATION_SECONDS);
            _expComboBoxTimer.Start();
            btnExp.BackColor = Color.LightGreen;
        }

        private void cmbSpeed_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!cmbSpeed.Focused) return;
            _speedComboBoxLockUntil = DateTime.Now.AddSeconds(LOCK_DURATION_SECONDS);
            _speedComboBoxTimer.Start();
            btnSpeed.BackColor = Color.LightGreen;
        }

        // ===== ПОДКЛЮЧЕНИЕ =====

        private async void btnConection_Click(object sender, EventArgs e)
        {
            if (_isConnected)
            {
                await DisconnectDevice();
                return;
            }

            btnConection.BackColor = Color.Yellow;
            lblConnectionStatus.Text = "Статус: Поиск устройства...";
            lblConnectionStatus.ForeColor = Color.Blue;

            try
            {
                string foundPort = await FindDeviceAsync();

                if (string.IsNullOrEmpty(foundPort))
                {
                    lblConnectionStatus.Text = "Статус: Устройство не найдено";
                    lblConnectionStatus.ForeColor = Color.Red;
                    btnConection.BackColor = Color.LightGreen;
                    btnConection.Text = "Поиск устройства";
                    return;
                }

                await ConnectToDevice(foundPort);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblConnectionStatus.Text = "Статус: Ошибка подключения";
                lblConnectionStatus.ForeColor = Color.Red;
                btnConection.BackColor = Color.LightGreen;
                btnConection.Text = "Поиск устройства";
            }
        }

        private async Task<string> FindDeviceAsync()
        {
            var ports = SerialPort.GetPortNames();
            if (ports.Length == 0)
            {
                MessageBox.Show("Не найдено ни одного COM-порта!", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return string.Empty;
            }

            foreach (string port in ports)
            {
                try
                {
                    using (var sp = new SerialPort(port, 38400, Parity.None, 8, StopBits.One))
                    {
                        sp.ReadTimeout = 500;
                        sp.WriteTimeout = 500;
                        sp.Open();
                        sp.WriteLine("PING");

                        DateTime startTime = DateTime.Now;
                        while ((DateTime.Now - startTime).TotalMilliseconds < 500)
                        {
                            if (sp.BytesToRead > 0 && sp.ReadLine().Trim() == "PONG")
                                return port;
                            Thread.Sleep(10);
                        }
                    }
                }
                catch { /* Игнорируем ошибки при проверке портов */ }
            }
            return string.Empty;
        }

        private async Task ConnectToDevice(string port)
        {
            try
            {
                _serialPort = new SerialPort(port, 38400, Parity.None, 8, StopBits.One)
                {
                    ReadTimeout = 500,
                    WriteTimeout = 500
                };
                _serialPort.Open();
                _isConnected = true;

                btnConection.Text = "Отключиться";
                await CheckBackgroundStatus();
                SetAllControlsEnabled(true);
                ResetChart();
                StartPolling();

                // Убеждаемся, что кнопка зеленая
                btnRecordStart.BackColor = Color.LightGreen;

                MessageBox.Show($"Устройство успешно подключено на порту {port}!",
                    "Подключение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                _isConnected = false;
                _serialPort?.Close();
                _serialPort?.Dispose();
                throw new Exception($"Не удалось подключиться к {port}: {ex.Message}");
            }
        }

        private async Task CheckBackgroundStatus()
        {
            try
            {
                string status = await SendCommandAndGetResponse("GET:BACKGROUND_STATUS");
                if (status == "MEASURING")
                {
                    _isBackgroundMeasuring = true;
                    LockControlsDuringBackgroundMeasurement();
                    lblBackgroundRadiation.Text = "Измерение фона...";
                    lblBackgroundRadiation.ForeColor = Color.Blue;
                    _ = MonitorBackgroundMeasurement();
                }
                else if (status == "DONE")
                {
                    string result = await SendCommandAndGetResponse("GET:BACKGROUND");
                    if (int.TryParse(result, out int bgValue))
                    {
                        _backgroundValue = bgValue;
                        _isBackgroundMeasuring = false;
                        lblBackgroundRadiation.Text = $"{bgValue} Имп/мин";
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка проверки статуса фона: {ex.Message}");
                _isBackgroundMeasuring = false;
            }
        }

        private async Task MonitorBackgroundMeasurement()
        {
            while (_isBackgroundMeasuring && _isConnected)
            {
                try
                {
                    string status = await SendCommandAndGetResponse("GET:BACKGROUND_STATUS");
                    if (status == "DONE" || status == "IDLE")
                    {
                        if (status == "DONE")
                        {
                            string result = await SendCommandAndGetResponse("GET:BACKGROUND");
                            if (int.TryParse(result, out int bgValue))
                            {
                                _backgroundValue = bgValue;
                                _isBackgroundMeasuring = false;
                                lblBackgroundRadiation.Text = $"{bgValue} Имп/мин";
                            }
                        }
                        else
                        {
                            _isBackgroundMeasuring = false;
                        }
                        UnlockControlsAfterBackgroundMeasurement();
                        break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка мониторинга фона: {ex.Message}");
                }
                await Task.Delay(1000);
            }
        }

        private async Task DisconnectDevice()
        {
            _isConnected = false;

            // Останавливаем счет жидкости при отключении
            if (_liquidCounting)
            {
                StopLiquidCounting(false);
            }

            if (_isBackgroundMeasuring)
            {
                _backgroundCancellation?.Cancel();
                _isBackgroundMeasuring = false;
                btnBKG.Text = "Измерить фон";
                btnBKG.BackColor = SystemColors.Control;
            }

            SetAllControlsEnabled(false);
            _pollingCancellation?.Cancel();
            _pollingCancellation?.Dispose();
            _pollingCancellation = null;

            if (_pollingTask != null && !_pollingTask.IsCompleted)
            {
                try { await _pollingTask; }
                catch (OperationCanceledException) { }
            }

            _serialPort?.Close();
            _serialPort?.Dispose();
            _serialPort = null;

            btnConection.Text = "Поиск устройства";
            btnConection.BackColor = Color.LightGreen;
            lblConnectionStatus.Text = "Статус: Отключен";
            lblConnectionStatus.ForeColor = Color.Gray;

            ClearDisplay();
            ResetChart();
        }

        // ===== УПРАВЛЕНИЕ УСТРОЙСТВОМ =====

        private async void btnPump_Click(object sender, EventArgs e)
        {
            if (_isBackgroundMeasuring)
            {
                MessageBox.Show("Невозможно включить насос во время измерения фона!",
                    "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string response = await SendCommandAndGetResponse("GET:PUMP");
                bool isPumpOn = response == "1";
                await SendCommandAsync(isPumpOn ? "SET:PUMP:OFF" : "SET:PUMP:ON");

                // Только при ВКЛЮЧЕНИИ насоса сбрасываем график
                if (!isPumpOn)
                {
                    // Включаем насос - сбрасываем график
                    ResetChart();
                    _pumpStartTime = DateTime.Now;
                    _isFirstPoint = true;
                    _lastTotalValue = 0;

                    // Очищаем старые точки графика
                    if (InvokeRequired)
                    {
                        Invoke(new Action(() =>
                        {
                            chartIMPtime.Series["Импульсы"].Points.Clear();
                        }));
                    }
                    else
                    {
                        chartIMPtime.Series["Импульсы"].Points.Clear();
                    }

                    // Если счет был остановлен (кнопка в состоянии "Сброс") - 
                    // автоматически возобновляем счет при включении насоса
                    if (btnCalcLiquid.Text == "Сброс")
                    {
                        // Возобновляем счет
                        _liquidCounting = true;
                        _liquidLastUpdate = DateTime.Now;
                        _liquidTimer.Start();

                        if (InvokeRequired)
                        {
                            Invoke(new Action(() =>
                            {
                                btnCalcLiquid.Text = "Стоп";
                                btnCalcLiquid.BackColor = Color.OrangeRed;
                            }));
                        }
                        else
                        {
                            btnCalcLiquid.Text = "Стоп";
                            btnCalcLiquid.BackColor = Color.OrangeRed;
                        }
                    }
                }
                else
                {
                    // При ВЫКЛЮЧЕНИИ насоса останавливаем счет жидкости
                    if (_liquidCounting)
                    {
                        StopLiquidCounting(true);
                    }
                }

                UpdateButtonsAvailability();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка переключения насоса: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnDir_Click(object sender, EventArgs e)
        {
            if (!_isConnected || _isBackgroundMeasuring)
            {
                MessageBox.Show(_isConnected ? "Идет измерение фона!" : "Сначала подключитесь к устройству!",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string response = await SendCommandAndGetResponse("GET:DIR");
                await SendCommandAsync(response == "1" ? "SET:DIR:RIGHT" : "SET:DIR:LEFT");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка переключения направления: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnResetCounter_Click(object sender, EventArgs e)
        {
            if (!_isConnected || _isBackgroundMeasuring)
            {
                MessageBox.Show(_isConnected ? "Идет измерение фона!" : "Сначала подключитесь к устройству!",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Сбросить общий счетчик?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try { await SendCommandAsync("RESET:TOTAL"); }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сброса счетчика: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void btnExp_Click(object sender, EventArgs e)
        {
            if (!_isConnected || _isBackgroundMeasuring)
            {
                MessageBox.Show(_isConnected ? "Идет измерение фона!" : "Сначала подключитесь к устройству!",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbExp.SelectedItem == null)
            {
                MessageBox.Show("Выберите время экспозиции!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (await SendCommandAndGetResponse("GET:PUMP") == "1")
                {
                    MessageBox.Show("Невозможно изменить экспозицию при включенном насосе!", "Предупреждение",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                float expoValue = float.Parse(cmbExp.SelectedItem.ToString(),
                    System.Globalization.CultureInfo.InvariantCulture);
                await SendCommandAsync($"SET:EXPO:{expoValue.ToString(System.Globalization.CultureInfo.InvariantCulture)}");

                _lastExpoTime = expoValue;
                _expComboBoxLockUntil = DateTime.MinValue;
                _expComboBoxTimer.Stop();
                btnExp.BackColor = SystemColors.Control;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка установки экспозиции: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnSpeed_Click(object sender, EventArgs e)
        {
            if (!_isConnected || _isBackgroundMeasuring)
            {
                MessageBox.Show(_isConnected ? "Идет измерение фона!" : "Сначала подключитесь к устройству!",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbSpeed.SelectedItem == null)
            {
                MessageBox.Show("Выберите скорость!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Получаем числовое значение из строки отображения
                string selectedText = cmbSpeed.SelectedItem.ToString();
                int speedValue = GetSpeedValueFromDisplay(selectedText);

                await SendCommandAsync($"SET:SPEED:{speedValue}");
                _speedComboBoxLockUntil = DateTime.MinValue;
                _speedComboBoxTimer.Stop();
                btnSpeed.BackColor = SystemColors.Control;

                // Если счет жидкости активен - обновляем время последнего обновления
                // чтобы пересчет шел по новой скорости
                if (_liquidCounting)
                {
                    _liquidLastUpdate = DateTime.Now;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка установки скорости: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ===== СЧЕТ ЖИДКОСТИ =====

        private void btnCalcLiquid_Click(object sender, EventArgs e)
        {
            if (!_isConnected)
            {
                // Молча игнорируем, если нет подключения
                return;
            }

            // Состояние 1: "Начать счет" -> запускаем счет
            if (btnCalcLiquid.Text == "Начать счет")
            {
                // Проверяем, включен ли насос
                if (lblPump.Text != "ВКЛЮЧЕН")
                {
                    // Насос выключен - просто игнорируем
                    return;
                }

                StartLiquidCounting();
                return;
            }

            // Состояние 2: "Стоп" -> останавливаем счет
            if (btnCalcLiquid.Text == "Стоп")
            {
                StopLiquidCounting(true);
                return;
            }

            // Состояние 3: "Сброс" -> сбрасываем счетчик
            if (btnCalcLiquid.Text == "Сброс")
            {
                ResetLiquidCounter();
                return;
            }
        }

        // ===== ИЗМЕРЕНИЕ ФОНА =====

        private async void btnBKG_Click(object sender, EventArgs e)
        {
            if (!_isConnected)
            {
                MessageBox.Show("Сначала подключитесь к устройству!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Проверка на включенный насос
            if (lblPump.Text == "ВКЛЮЧЕН")
            {
                MessageBox.Show("Невозможно измерить фон при включенном насосе! Остановите насос.",
                    "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Остановка измерения
            if (_isBackgroundMeasuring)
            {
                try { await SendCommandAsync("BACKGROUND:STOP"); }
                catch (Exception ex) { Console.WriteLine($"Ошибка остановки: {ex.Message}"); }

                _backgroundCancellation?.Cancel();
                _isBackgroundMeasuring = false;
                btnBKG.Text = "Измерить фон";
                btnBKG.BackColor = SystemColors.Control;
                UpdateButtonsAvailability();
                return;
            }

            // Запуск измерения
            try
            {
                if (await SendCommandAndGetResponse("GET:PUMP") == "1")
                {
                    MessageBox.Show("Невозможно измерить фон при включенном насосе!", "Предупреждение",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _isBackgroundMeasuring = true;
                _backgroundCancellation = new CancellationTokenSource();
                LockControlsDuringBackgroundMeasurement();

                lblBackgroundRadiation.Text = "Измерение... 300 сек";
                lblBackgroundRadiation.ForeColor = Color.Green;

                await SendCommandAsync("BACKGROUND:START");

                DateTime startTime = DateTime.Now;
                const int totalSeconds = 300;
                bool measurementCompleted = false;

                while (!_backgroundCancellation.Token.IsCancellationRequested)
                {
                    int remaining = Math.Max(0, totalSeconds - (int)(DateTime.Now - startTime).TotalSeconds);
                    lblBackgroundRadiation.Text = $"Измерение... {remaining} сек";

                    try
                    {
                        string status = await SendCommandAndGetResponse("GET:BACKGROUND_STATUS");
                        if (status == "DONE" || status == "IDLE" || (DateTime.Now - startTime).TotalSeconds >= 310)
                        {
                            measurementCompleted = status == "DONE";
                            break;
                        }
                    }
                    catch (Exception ex) { Console.WriteLine($"Ошибка проверки статуса: {ex.Message}"); }

                    await Task.Delay(500, _backgroundCancellation.Token);
                }

                if (!_backgroundCancellation.Token.IsCancellationRequested && measurementCompleted)
                {
                    string result = await SendCommandAndGetResponse("GET:BACKGROUND");
                    if (int.TryParse(result, out int bgValue))
                        _backgroundValue = bgValue;
                }
            }
            catch (Exception ex) when (!(ex is TaskCanceledException))
            {
                lblBackgroundRadiation.Text = "Ошибка измерения";
                lblBackgroundRadiation.ForeColor = Color.Red;
                MessageBox.Show($"Ошибка измерения фона: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                _isBackgroundMeasuring = false;
                _backgroundCancellation?.Dispose();
                _backgroundCancellation = null;
                UnlockControlsAfterBackgroundMeasurement();
            }
        }

        // ===== ЗАПИСЬ CSV =====

        private void btnRecordStart_Click(object sender, EventArgs e)
        {
            if (!_isConnected)
            {
                MessageBox.Show("Сначала подключитесь к устройству!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_isRecording)
                return;

            if (lblPump.Text != "ВКЛЮЧЕН" &&
                MessageBox.Show("Насос выключен. Начать запись все равно?", "Предупреждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                return;

            var saveFileDialog = new SaveFileDialog
            {
                Filter = "CSV файлы (*.csv)|*.csv|Все файлы (*.*)|*.*",
                DefaultExt = "csv",
                FileName = $"Flow data {DateTime.Now:dd.MM.yyyy HH.mm}.csv"
            };

            if (saveFileDialog.ShowDialog() != DialogResult.OK)
                return;

            _csvFilePath = saveFileDialog.FileName;
            _isRecording = true;
            _recordingStartTime = DateTime.Now;
            _recordingStopwatch.Restart();
            _csvRecords.Clear();
            _recordCounter = 0;

            try
            {
                // Используем UTF-8 с BOM для правильного отображения кириллицы
                var encoding = new System.Text.UTF8Encoding(true);
                using (var writer = new System.IO.StreamWriter(_csvFilePath, false, encoding))
                {
                    writer.WriteLine("Абсолютное время;Относительное время, с;Импульсы, имп/эксп;Все импульсы;Скорость насоса, %;Фоновое излучение, имп/мин;Объем жидкости, мл");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания файла: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                _isRecording = false;
                return;
            }

            btnRecordStart.Enabled = false;
            btnRecordStart.BackColor = Color.LightGray;
            btnRecordStop.Enabled = true;
            btnRecordStop.BackColor = Color.OrangeRed;
            lblTimeRecord.Text = $"Запись начата: {_recordingStartTime:HH:mm:ss}";
            lblTimeRecord.ForeColor = Color.Green;
        }

        private void btnRecordStop_Click(object sender, EventArgs e)
        {
            if (!_isRecording)
            {
                MessageBox.Show("Запись не идет!", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            _isRecording = false;
            _recordingStopwatch.Stop();

            try
            {
                // Используем UTF-8 с BOM для правильного отображения кириллицы
                var encoding = new System.Text.UTF8Encoding(true);
                using (var writer = new System.IO.StreamWriter(_csvFilePath, true, encoding))
                {
                    foreach (string record in _csvRecords)
                        writer.WriteLine(record);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            btnRecordStart.Enabled = true;
            btnRecordStart.BackColor = Color.LightGreen;
            btnRecordStop.Enabled = false;
            btnRecordStop.BackColor = Color.LightGray;
            lblTimeRecord.Text = $"Запись остановлена: {DateTime.Now:HH:mm:ss}";
            lblTimeRecord.ForeColor = Color.Gray;

            if (_recordCounter > 0)
            {
                MessageBox.Show($"Данные сохранены в файл:\n{_csvFilePath}\n\nВсего записей: {_recordCounter}",
                    "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void AddCSVRecord(DateTime timestamp, int pulses, long total, int speedPercent, int background)
        {
            if (!_isRecording) return;

            string absoluteTime = timestamp.ToString("HH:mm:ss.f");
            string relativeTime = _recordingStopwatch.Elapsed.TotalSeconds
                .ToString("F1", System.Globalization.CultureInfo.InvariantCulture)
                .Replace('.', ',');

            // Добавляем текущий объем жидкости
            string liquidVolume = _liquidVolume.ToString("F2", System.Globalization.CultureInfo.InvariantCulture).Replace('.', ',');

            _csvRecords.Add($"{absoluteTime};{relativeTime};{pulses};{total};{speedPercent};{background};{liquidVolume}");
            _recordCounter++;

            if (_csvRecords.Count >= 10)
                FlushCSVRecords();
        }

        private void FlushCSVRecords()
        {
            if (string.IsNullOrEmpty(_csvFilePath) || _csvRecords.Count == 0)
                return;

            try
            {
                // Используем UTF-8 с BOM для правильного отображения кириллицы
                var encoding = new System.Text.UTF8Encoding(true);
                using (var writer = new System.IO.StreamWriter(_csvFilePath, true, encoding))
                {
                    foreach (string record in _csvRecords)
                        writer.WriteLine(record);
                }
                _csvRecords.Clear();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка сохранения CSV: {ex.Message}");
            }
        }

        // ===== ГРАФИК =====

        private void AddChartPoint(int pulses, DateTime timestamp)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => AddChartPoint(pulses, timestamp)));
                return;
            }

            var series = chartIMPtime.Series["Импульсы"];
            if (series == null) return;

            double minutesFromStart = (timestamp - _pumpStartTime).TotalMinutes;
            series.Points.AddXY(minutesFromStart, pulses);

            if (series.Points.Count > 1000)
                series.Points.RemoveAt(0);

            if (series.Points.Count > 0)
            {
                double maxY = 0;
                foreach (var point in series.Points)
                {
                    if (point.YValues[0] > maxY)
                        maxY = point.YValues[0];
                }

                double newMax = Math.Max(10, Math.Ceiling(maxY * 1.2 / 50) * 50);
                var area = chartIMPtime.ChartAreas[0];
                area.AxisY.Maximum = newMax;
                area.AxisY.Minimum = 0;
                area.AxisY.Interval = Math.Max(10, newMax / 10);
            }

            double timeRangeMinutes = Math.Max(_lastExpoTime * 20, 60) / 60.0;
            var axisX = chartIMPtime.ChartAreas[0].AxisX;
            axisX.Minimum = Math.Max(0, minutesFromStart - timeRangeMinutes);
            axisX.Maximum = Math.Max(timeRangeMinutes, minutesFromStart + 0.5);
            axisX.Interval = Math.Max(0.5, (axisX.Maximum - axisX.Minimum) / 10);

            chartIMPtime.Invalidate();
        }

        // ===== ОПРОС =====

        private void StartPolling()
        {
            _pollingCancellation = new CancellationTokenSource();
            _pollingTask = Task.Run(async () =>
            {
                while (!_pollingCancellation.Token.IsCancellationRequested)
                {
                    try
                    {
                        if (_isConnected && _serialPort != null && _serialPort.IsOpen)
                            await RequestFullStatus();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка опроса: {ex.Message}");
                    }
                    await Task.Delay(100, _pollingCancellation.Token);
                }
            }, _pollingCancellation.Token);
        }

        private async Task RequestFullStatus()
        {
            try
            {
                string response = await SendCommandAndGetResponse("GET:FULLSTATUS");
                if (string.IsNullOrEmpty(response)) return;

                string dataPart = response;
                if (response.StartsWith("FULLSTATUS:", StringComparison.OrdinalIgnoreCase))
                    dataPart = response.Substring(11);
                else if (response.StartsWith("FULLSTATUS", StringComparison.OrdinalIgnoreCase))
                    dataPart = response.Substring(10);

                var parts = dataPart.Split(',');
                if (parts.Length < 10) return;

                int pumpState = int.Parse(parts[0].Trim());
                int dirState = int.Parse(parts[1].Trim());
                float expoTime = float.Parse(parts[2].Trim(), System.Globalization.CultureInfo.InvariantCulture);
                int speed = int.Parse(parts[3].Trim());
                int counter = int.Parse(parts[4].Trim());
                long total = long.Parse(parts[5].Trim());
                int hvState = int.Parse(parts[6].Trim());
                int pumpTime = int.Parse(parts[7].Trim());
                float hvVoltage = float.Parse(parts[8].Trim(), System.Globalization.CultureInfo.InvariantCulture);
                int background = int.Parse(parts[9].Trim());

                _lastHVVoltage = hvVoltage;
                if (!_isBackgroundMeasuring)
                    _backgroundValue = background;

                UpdateUI(pumpState, dirState, expoTime, speed, counter, total, hvState, pumpTime, hvVoltage, background);

                if (pumpState == 1)
                {
                    _lastExpoTime = expoTime;
                    DateTime now = DateTime.Now;

                    if (_isFirstPoint || (now - _lastChartUpdate).TotalSeconds >= expoTime)
                    {
                        int pulsesSinceLastUpdate;

                        if (_isFirstPoint)
                        {
                            pulsesSinceLastUpdate = 0;
                            _lastTotalValue = total;
                            _isFirstPoint = false;
                        }
                        else
                        {
                            pulsesSinceLastUpdate = (int)(total - _lastTotalValue);
                            _lastTotalValue = total;
                        }

                        _lastChartUpdate = now;
                        AddChartPoint(pulsesSinceLastUpdate, now);
                        AddCSVRecord(now, pulsesSinceLastUpdate, total, speed, _backgroundValue);
                    }
                }
                // При выключении насоса _isFirstPoint НЕ сбрасывается!
                // Это позволяет сохранить график при остановке насоса

                UpdateButtonsAvailability();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка парсинга FULLSTATUS: {ex.Message}");
            }
        }

        // ===== ОБНОВЛЕНИЕ UI =====

        private void UpdateUI(int pumpState, int dirState, float expoTime, int speed,
                            int counter, long total, int hvState, int pumpTime,
                            float hvVoltage, int background)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => UpdateUI(pumpState, dirState, expoTime, speed,
                    counter, total, hvState, pumpTime, hvVoltage, background)));
                return;
            }

            lblPump.Text = pumpState == 1 ? "ВКЛЮЧЕН" : "ВЫКЛЮЧЕН";
            lblPump.ForeColor = pumpState == 1 ? Color.Green : Color.Red;

            lblDir.Text = dirState == 1 ? "↻ ВЛЕВО " : "ВПРАВО ↺";
            lblCounter.Text = $"Текущий: {counter} | Общий: {total}";

            int minutes = pumpTime / 60, seconds = pumpTime % 60;
            lblTime.Text = $"Время работы: {minutes} м {seconds} с";

            if (hvVoltage >= 2.0f)
            {
                lblHV.Text = "Напряжение СБМ-20 в норме";
                lblHV.ForeColor = Color.Green;
            }
            else
            {
                lblHV.Text = "Напряжение СБМ-20 Ошибка";
                lblHV.ForeColor = Color.Red;
            }

            if (!_isBackgroundMeasuring)
                lblBackgroundRadiation.Text = $"{background} Имп/мин";

            // Обновление комбобокса EXP
            if (DateTime.Now >= _expComboBoxLockUntil)
            {
                string expoStr = expoTime.ToString("0.#", System.Globalization.CultureInfo.InvariantCulture);
                if (cmbExp.SelectedItem?.ToString() != expoStr)
                {
                    int index = cmbExp.Items.IndexOf(expoStr);
                    if (index >= 0)
                        cmbExp.SelectedIndex = index;
                    else
                    {
                        cmbExp.Items.Add(expoStr);
                        cmbExp.SelectedIndex = cmbExp.Items.Count - 1;
                    }
                }
            }

            // Обновление комбобокса SPEED с отображением
            if (DateTime.Now >= _speedComboBoxLockUntil)
            {
                // Ищем отображение по значению скорости
                if (_speedDisplayMap.TryGetValue(speed, out string displayText))
                {
                    if (cmbSpeed.SelectedItem?.ToString() != displayText)
                    {
                        int index = cmbSpeed.Items.IndexOf(displayText);
                        if (index >= 0)
                            cmbSpeed.SelectedIndex = index;
                    }
                }
            }

            lblConnectionStatus.Text = $"Статус: Обновлено {DateTime.Now:HH:mm:ss}";
            lblConnectionStatus.ForeColor = Color.Green;
        }

        // ===== РАБОТА С ПОРТОМ =====

        private async Task SendCommandAsync(string command)
        {
            if (!_isConnected || _serialPort == null || !_serialPort.IsOpen)
                throw new InvalidOperationException("Устройство не подключено");

            await Task.Run(() =>
            {
                lock (_serialLock)
                {
                    _serialPort.DiscardInBuffer();
                    _serialPort.WriteLine(command);
                    _serialPort.BaseStream.Flush();
                }
            });
        }

        private async Task<string> SendCommandAndGetResponse(string command)
        {
            if (!_isConnected || _serialPort == null || !_serialPort.IsOpen)
                throw new InvalidOperationException("Устройство не подключено");

            return await Task.Run(() =>
            {
                lock (_serialLock)
                {
                    _serialPort.DiscardInBuffer();
                    _serialPort.WriteLine(command);
                    _serialPort.BaseStream.Flush();

                    DateTime startTime = DateTime.Now;
                    string lastLine = string.Empty;

                    while ((DateTime.Now - startTime).TotalMilliseconds < 500)
                    {
                        if (_serialPort.BytesToRead > 0)
                        {
                            string line = _serialPort.ReadLine().Trim();
                            if (!string.IsNullOrEmpty(line))
                            {
                                lastLine = line;
                                if (!line.StartsWith("CMD:") && line != command)
                                    return line;
                            }
                        }
                        Thread.Sleep(10);
                    }
                    return lastLine;
                }
            });
        }

        // ===== ЗАКРЫТИЕ =====

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_isConnected) return;

            if (MessageBox.Show("Отключиться от устройства и выйти?", "Выход",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _isConnected = false;
                _backgroundCancellation?.Cancel();
                _pollingCancellation?.Cancel();
                _serialPort?.Close();
                _serialPort?.Dispose();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://github.com/andewmyitt/FlowCounter",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось открыть справочную страницу: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Заглушки для отсутствующих элементов (если они есть в дизайнере)
        private void chartIMPtime_Click(object sender, EventArgs e) { }
    }
}