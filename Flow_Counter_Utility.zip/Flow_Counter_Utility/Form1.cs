﻿using System;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;

namespace Flow_Counter_Utility
{
    public partial class Form1 : Form
    {
        private SerialPort serialPort;
        private System.Windows.Forms.Timer statusTimer;
        private System.Windows.Forms.Timer pumpTimeTimer;
        private System.Windows.Forms.Timer csvRecordTimer; // Новый таймер для CSV

        // Состояния устройства
        private bool isConnected = false;
        private bool isPumpOn = false;
        private bool isDirLeft = true;
        private float currentExposition = 30.0f;
        private int currentSpeed = 0;
        private int currentCounter = 0;
        private long totalCounter = 0;
        private bool isHVOn = false;

        // Время работы помпы
        private int pumpMinutes = 0;
        private int pumpSeconds = 0;

        // Флаги
        private bool isLoadingComboBoxes = true;

        // Временные значения
        private float? pendingExposition = null;
        private int? pendingSpeed = null;

        // CSV
        private bool isRecording = false;
        private string csvFilePath = "";
        private DateTime lastCsvRecordTime = DateTime.MinValue;
        private int lastRecordedCounter = 0;
        private long lastRecordedTotal = 0;

        public Form1()
        {
            InitializeComponent();
            InitializeCustomLogic();
        }

        private void InitializeCustomLogic()
        {
            isLoadingComboBoxes = true;

            // Значения экспозиции: 0.1, 1, 10, 20, 30... 120
            cmbExp.Items.Add("0.1");
            cmbExp.Items.Add("1");
            for (int i = 10; i <= 120; i += 10)
            {
                cmbExp.Items.Add(i.ToString());
            }

            cmbExp.SelectedIndex = -1;

            // Скорость
            for (int i = 0; i <= 100; i += 10)
            {
                cmbSpeed.Items.Add(i.ToString());
            }

            cmbSpeed.SelectedIndex = -1;

            isLoadingComboBoxes = false;

            UpdateLabels();

            // Кнопки
            btnConection.Click += BtnConection_Click;
            btnRefresh.Click += BtnRefresh_Click;
            btnPump.Click += BtnPump_Click;
            btnDir.Click += BtnDir_Click;
            btnExp.Click += BtnExp_Click;
            btnSpeed.Click += BtnSpeed_Click;
            btnResetCounter.Click += BtnResetCounter_Click;
            btnRecordStart.Click += BtnRecordStart_Click;
            btnRecordStop.Click += BtnRecordStop_Click;

            cmbExp.SelectedIndexChanged += CmbExp_SelectedIndexChanged;
            cmbSpeed.SelectedIndexChanged += CmbSpeed_SelectedIndexChanged;

            // Таймер статуса
            statusTimer = new System.Windows.Forms.Timer();
            statusTimer.Interval = 500;
            statusTimer.Tick += StatusTimer_Tick;

            // Таймер времени работы
            pumpTimeTimer = new System.Windows.Forms.Timer();
            pumpTimeTimer.Interval = 1000;
            pumpTimeTimer.Tick += PumpTimeTimer_Tick;

            // Таймер для CSV записи - будет динамически менять интервал
            csvRecordTimer = new System.Windows.Forms.Timer();
            csvRecordTimer.Tick += CsvRecordTimer_Tick;

            SetControlsEnabled(false);

            btnRecordStop.Enabled = false;

            RefreshCOMPorts();
        }

        private void RefreshCOMPorts()
        {
            cmbCOM.Items.Clear();
            string[] ports = SerialPort.GetPortNames();

            if (ports.Length > 0)
            {
                cmbCOM.Items.AddRange(ports);
                cmbCOM.SelectedIndex = 0;
                cmbCOM.Enabled = true;
                btnConection.Enabled = true;
            }
            else
            {
                cmbCOM.Items.Add("Нет доступных портов");
                cmbCOM.SelectedIndex = 0;
                cmbCOM.Enabled = false;
                btnConection.Enabled = false;
            }
        }

        private void SetControlsEnabled(bool enabled)
        {
            btnPump.Enabled = enabled;
            btnDir.Enabled = enabled;
            btnExp.Enabled = enabled;
            btnSpeed.Enabled = enabled;
            btnResetCounter.Enabled = enabled;
            cmbExp.Enabled = enabled;
            cmbSpeed.Enabled = enabled;
        }

        private void UpdateLabels()
        {
            if (lblPump.InvokeRequired)
            {
                lblPump.Invoke(new Action(UpdateLabels));
                return;
            }

            lblPump.Text = isPumpOn ? "ВКЛЮЧЕН" : "ВЫКЛЮЧЕН";
            lblPump.ForeColor = isPumpOn ? System.Drawing.Color.Green : System.Drawing.Color.Red;

            lblDir.Text = isDirLeft ? "ВЛЕВО" : "ВПРАВО";
            lblDir.ForeColor = isDirLeft ? System.Drawing.Color.Blue : System.Drawing.Color.Orange;

            lblCounter.Text = $"Текущий: {currentCounter} | Общий: {totalCounter}";

            UpdateHVLabel();
        }

        private void UpdateHVLabel()
        {
            if (lblHV.InvokeRequired)
            {
                lblHV.Invoke(new Action(UpdateHVLabel));
                return;
            }

            if (isHVOn)
            {
                lblHV.Text = "Напряжение СБМ-20: 300 Вольт подано";
                lblHV.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblHV.Text = "Напряжение СБМ-20: Ошибка";
                lblHV.ForeColor = System.Drawing.Color.Red;
            }
        }

        private void UpdatePumpTimeDisplay()
        {
            if (lblTime.InvokeRequired)
            {
                lblTime.Invoke(new Action(UpdatePumpTimeDisplay));
                return;
            }

            lblTime.Text = $"Время работы: {pumpMinutes:D2}:{pumpSeconds:D2}";
        }

        private void SendCommand(string command)
        {
            if (!isConnected || serialPort == null || !serialPort.IsOpen)
                return;

            try
            {
                serialPort.WriteLine(command);
            }
            catch (Exception ex)
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(new Action(() =>
                        MessageBox.Show($"Ошибка отправки: {ex.Message}")));
                }
                else
                {
                    MessageBox.Show($"Ошибка отправки: {ex.Message}");
                }
            }
        }

        private void BtnConection_Click(object sender, EventArgs e)
        {
            if (!isConnected)
                ConnectToDevice();
            else
                DisconnectFromDevice();
        }

        private void ConnectToDevice()
        {
            try
            {
                serialPort = new SerialPort(
                    cmbCOM.SelectedItem.ToString(),
                    38400,
                    Parity.None,
                    8,
                    StopBits.One);

                serialPort.DataReceived += SerialPort_DataReceived;
                serialPort.Open();

                isConnected = true;

                btnConection.Text = "Отключить";
                btnRefresh.Enabled = false;
                cmbCOM.Enabled = false;

                SetControlsEnabled(true);

                SendCommand("GET:STATUS");

                statusTimer.Start();
                pumpTimeTimer.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения: {ex.Message}");
            }
        }

        private void DisconnectFromDevice()
        {
            if (isRecording)
            {
                StopRecording();
            }

            statusTimer.Stop();
            pumpTimeTimer.Stop();
            csvRecordTimer.Stop();

            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.Close();
                serialPort.Dispose();
            }

            isConnected = false;

            btnConection.Text = "Подключить";
            btnRefresh.Enabled = true;
            cmbCOM.Enabled = true;

            SetControlsEnabled(false);

            RefreshCOMPorts();
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            RefreshCOMPorts();
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string data = serialPort.ReadExisting();

            if (!string.IsNullOrEmpty(data))
            {
                try
                {
                    if (this.InvokeRequired)
                    {
                        this.Invoke(new Action(() => ProcessResponse(data)));
                    }
                    else
                    {
                        ProcessResponse(data);
                    }
                }
                catch
                {
                    // Логирование ошибки можно добавить здесь
                }
            }
        }

        private void ProcessResponse(string data)
        {
            string[] lines = data.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string line in lines)
            {
                try
                {
                    if (line.StartsWith("STATUS:"))
                    {
                        string[] parts = line.Substring(7).Split(',');

                        if (parts.Length >= 7)
                        {
                            isPumpOn = parts[0] == "1";
                            isDirLeft = parts[1] == "1";

                            float.TryParse(parts[2], System.Globalization.NumberStyles.Any,
                                System.Globalization.CultureInfo.InvariantCulture, out currentExposition);
                            int.TryParse(parts[3], out currentSpeed);
                            int.TryParse(parts[4], out currentCounter);
                            long.TryParse(parts[5], out totalCounter);
                            isHVOn = parts[6] == "1";

                            UpdateLabels();

                            isLoadingComboBoxes = true;

                            string expoDisplay;
                            if (Math.Abs(currentExposition - (int)currentExposition) < 0.01f)
                            {
                                expoDisplay = ((int)currentExposition).ToString();
                            }
                            else
                            {
                                expoDisplay = currentExposition.ToString("0.0",
                                    System.Globalization.CultureInfo.InvariantCulture);
                            }

                            if (cmbExp.SelectedItem?.ToString() != expoDisplay)
                            {
                                cmbExp.SelectedItem = expoDisplay;
                            }

                            if (cmbSpeed.SelectedItem?.ToString() != currentSpeed.ToString())
                            {
                                cmbSpeed.SelectedItem = currentSpeed.ToString();
                            }

                            isLoadingComboBoxes = false;
                        }
                    }
                    else if (line.StartsWith("PUMPTIME:"))
                    {
                        string[] parts = line.Substring(9).Split(':');

                        if (parts.Length == 2)
                        {
                            pumpMinutes = int.Parse(parts[0]);
                            pumpSeconds = int.Parse(parts[1]);

                            UpdatePumpTimeDisplay();
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Ошибка обработки: {ex.Message}");
                }
            }
        }

        private void StatusTimer_Tick(object sender, EventArgs e)
        {
            if (isConnected && serialPort != null && serialPort.IsOpen)
            {
                try
                {
                    SendCommand("GET:STATUS");
                }
                catch
                {
                    // Логирование ошибки можно добавить здесь
                }
            }
        }

        private void PumpTimeTimer_Tick(object sender, EventArgs e)
        {
            if (isConnected && isPumpOn && serialPort != null && serialPort.IsOpen)
            {
                try
                {
                    SendCommand("GET:PUMPTIME");
                }
                catch
                {
                    // Логирование ошибки можно добавить здесь
                }
            }
        }

        private void BtnPump_Click(object sender, EventArgs e)
        {
            if (isPumpOn)
            {
                SendCommand("SET:PUMP:OFF");
                pumpMinutes = 0;
                pumpSeconds = 0;
                UpdatePumpTimeDisplay();

                // Останавливаем таймер записи CSV
                if (isRecording)
                {
                    csvRecordTimer.Stop();
                }
            }
            else
            {
                SendCommand("SET:PUMP:ON");

                // Если идет запись, запускаем таймер с интервалом экспозиции
                if (isRecording)
                {
                    StartCsvRecordingTimer();
                }
            }
        }

        private void BtnDir_Click(object sender, EventArgs e)
        {
            if (isDirLeft)
                SendCommand("SET:DIR:RIGHT");
            else
                SendCommand("SET:DIR:LEFT");
        }

        private void CmbExp_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isLoadingComboBoxes && cmbExp.SelectedItem != null)
            {
                string selectedValue = cmbExp.SelectedItem.ToString();
                pendingExposition = float.Parse(selectedValue,
                    System.Globalization.CultureInfo.InvariantCulture);
            }
        }

        private void CmbSpeed_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isLoadingComboBoxes && cmbSpeed.SelectedItem != null)
            {
                pendingSpeed = int.Parse(cmbSpeed.SelectedItem.ToString());
            }
        }

        private void BtnExp_Click(object sender, EventArgs e)
        {
            if (pendingExposition.HasValue && Math.Abs(pendingExposition.Value - currentExposition) > 0.01f)
            {
                string expoValue = pendingExposition.Value.ToString("0.0",
                    System.Globalization.CultureInfo.InvariantCulture);
                SendCommand($"SET:EXPO:{expoValue}");
            }
        }

        private void BtnSpeed_Click(object sender, EventArgs e)
        {
            if (pendingSpeed.HasValue && pendingSpeed.Value != currentSpeed)
            {
                SendCommand($"SET:SPEED:{pendingSpeed.Value}");
            }
        }

        private void BtnResetCounter_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Сбросить общий счетчик?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                SendCommand("RESET:TOTAL");
            }
        }

        private void BtnRecordStart_Click(object sender, EventArgs e)
        {
            if (!isConnected)
            {
                MessageBox.Show("Сначала подключитесь к устройству!");
                return;
            }

            StartRecording();
        }

        private void BtnRecordStop_Click(object sender, EventArgs e)
        {
            StopRecording();
        }

        private void StartRecording()
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                saveFileDialog.Filter = "CSV files (*.csv)|*.csv";
                saveFileDialog.FileName =
                    $"FlowCounter_{DateTime.Now:yyyyMMdd_HHmmss}.csv";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    csvFilePath = saveFileDialog.FileName;

                    // Записываем заголовок
                    using (StreamWriter sw = new StreamWriter(
                        csvFilePath,
                        false,
                        System.Text.Encoding.UTF8))
                    {
                        sw.WriteLine("Время записи;Время работы;Отчеты за экспозицию;Отчеты суммарно;Экспозиция (сек);Скорость (%);HV статус");
                    }

                    isRecording = true;

                    // Сбрасываем счетчики для записи
                    lastCsvRecordTime = DateTime.MinValue;
                    lastRecordedCounter = 0;
                    lastRecordedTotal = 0;

                    btnRecordStart.Enabled = false;
                    btnRecordStop.Enabled = true;

                    // Блокируем изменение экспозиции во время записи
                    cmbExp.Enabled = false;
                    btnExp.Enabled = false;

                    // Если насос включен, запускаем таймер записи
                    if (isPumpOn)
                    {
                        StartCsvRecordingTimer();
                    }

                    MessageBox.Show($"Запись начата. Файл: {csvFilePath}\nИнтервал записи: {currentExposition} сек");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка записи: {ex.Message}");
            }
        }

        private void StartCsvRecordingTimer()
        {
            // Останавливаем старый таймер
            csvRecordTimer.Stop();

            // Устанавливаем интервал в миллисекундах (экспозиция * 1000)
            int interval = (int)(currentExposition * 1000);

            // Минимальный интервал - 100 мс (для 0.1 секунды)
            if (interval < 100) interval = 100;

            csvRecordTimer.Interval = interval;
            lastCsvRecordTime = DateTime.Now;

            // Записываем первое значение сразу
            WriteDataToCSV();

            // Запускаем таймер
            csvRecordTimer.Start();

            System.Diagnostics.Debug.WriteLine($"Таймер CSV запущен с интервалом: {interval} мс");
        }

        private void StopRecording()
        {
            isRecording = false;
            csvRecordTimer.Stop();

            btnRecordStart.Enabled = true;
            btnRecordStop.Enabled = false;

            // Разблокируем изменение экспозиции
            cmbExp.Enabled = true;
            btnExp.Enabled = true;

            MessageBox.Show("Запись остановлена");
        }

        private void CsvRecordTimer_Tick(object sender, EventArgs e)
        {
            if (!isRecording || !isConnected || !isPumpOn)
            {
                // Если насос выключен, останавливаем таймер
                if (!isPumpOn)
                {
                    csvRecordTimer.Stop();
                }
                return;
            }

            // Проверяем, прошло ли достаточно времени с последней записи
            TimeSpan elapsed = DateTime.Now - lastCsvRecordTime;
            int requiredInterval = (int)(currentExposition * 1000);

            if (elapsed.TotalMilliseconds >= requiredInterval - 10) // Небольшая погрешность
            {
                WriteDataToCSV();
                lastCsvRecordTime = DateTime.Now;
            }
        }

        private void WriteDataToCSV()
        {
            try
            {
                if (!isRecording || !isConnected)
                    return;

                // Получаем актуальные данные
                string currentTime = DateTime.Now.ToString("HH:mm:ss.fff");
                string workTime = $"{pumpMinutes:D2}:{pumpSeconds:D2}";
                string hvStatus = isHVOn ? "300В подано" : "Ошибка";

                string expoDisplay;
                if (Math.Abs(currentExposition - (int)currentExposition) < 0.01f)
                {
                    expoDisplay = ((int)currentExposition).ToString();
                }
                else
                {
                    expoDisplay = currentExposition.ToString("0.0",
                        System.Globalization.CultureInfo.InvariantCulture);
                }

                // Используем текущие значения счетчиков
                string csvLine = $"{currentTime};{workTime};{currentCounter};{totalCounter};{expoDisplay};{currentSpeed};{hvStatus}";

                // Блокируем файл на время записи
                using (StreamWriter sw = new StreamWriter(
                    csvFilePath,
                    true,
                    System.Text.Encoding.UTF8))
                {
                    sw.WriteLine(csvLine);
                }

                // Для отладки
                System.Diagnostics.Debug.WriteLine($"CSV запись [{currentExposition}с]: {csvLine}");

                // Обновляем последние записанные значения
                lastRecordedCounter = currentCounter;
                lastRecordedTotal = totalCounter;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка записи CSV: {ex.Message}");
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (isRecording)
            {
                StopRecording();
            }

            if (isConnected)
            {
                DisconnectFromDevice();
            }

            base.OnFormClosing(e);
        }
    }
}