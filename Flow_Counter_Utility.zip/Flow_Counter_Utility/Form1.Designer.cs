﻿namespace Flow_Counter_Utility
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDir = new System.Windows.Forms.Button();
            this.btnConection = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnPump = new System.Windows.Forms.Button();
            this.cmbCOM = new System.Windows.Forms.ComboBox();
            this.cmbExp = new System.Windows.Forms.ComboBox();
            this.cmbSpeed = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblHV = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblCounter = new System.Windows.Forms.Label();
            this.lblDir = new System.Windows.Forms.Label();
            this.lblPump = new System.Windows.Forms.Label();
            this.btnSpeed = new System.Windows.Forms.Button();
            this.btnResetCounter = new System.Windows.Forms.Button();
            this.btnExp = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnRecordStop = new System.Windows.Forms.Button();
            this.btnRecordStart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDir
            // 
            this.btnDir.Location = new System.Drawing.Point(169, 48);
            this.btnDir.Name = "btnDir";
            this.btnDir.Size = new System.Drawing.Size(86, 23);
            this.btnDir.TabIndex = 0;
            this.btnDir.Text = "Переключить";
            this.btnDir.UseVisualStyleBackColor = true;
            // 
            // btnConection
            // 
            this.btnConection.Location = new System.Drawing.Point(170, 19);
            this.btnConection.Name = "btnConection";
            this.btnConection.Size = new System.Drawing.Size(86, 23);
            this.btnConection.TabIndex = 1;
            this.btnConection.Text = "Подключить";
            this.btnConection.UseVisualStyleBackColor = true;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(181, 48);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.UseVisualStyleBackColor = true;
            // 
            // btnPump
            // 
            this.btnPump.Location = new System.Drawing.Point(169, 14);
            this.btnPump.Name = "btnPump";
            this.btnPump.Size = new System.Drawing.Size(86, 23);
            this.btnPump.TabIndex = 3;
            this.btnPump.Text = "Переключить";
            this.btnPump.UseVisualStyleBackColor = true;
            // 
            // cmbCOM
            // 
            this.cmbCOM.FormattingEnabled = true;
            this.cmbCOM.Location = new System.Drawing.Point(6, 19);
            this.cmbCOM.Name = "cmbCOM";
            this.cmbCOM.Size = new System.Drawing.Size(121, 21);
            this.cmbCOM.TabIndex = 4;
            // 
            // cmbExp
            // 
            this.cmbExp.FormattingEnabled = true;
            this.cmbExp.Location = new System.Drawing.Point(5, 82);
            this.cmbExp.Name = "cmbExp";
            this.cmbExp.Size = new System.Drawing.Size(121, 21);
            this.cmbExp.TabIndex = 5;
            // 
            // cmbSpeed
            // 
            this.cmbSpeed.FormattingEnabled = true;
            this.cmbSpeed.Location = new System.Drawing.Point(5, 140);
            this.cmbSpeed.Name = "cmbSpeed";
            this.cmbSpeed.Size = new System.Drawing.Size(121, 21);
            this.cmbSpeed.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbCOM);
            this.groupBox1.Controls.Add(this.btnConection);
            this.groupBox1.Controls.Add(this.btnRefresh);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(262, 80);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Подключение к COM";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lblHV);
            this.groupBox2.Controls.Add(this.lblTime);
            this.groupBox2.Controls.Add(this.lblCounter);
            this.groupBox2.Controls.Add(this.lblDir);
            this.groupBox2.Controls.Add(this.lblPump);
            this.groupBox2.Controls.Add(this.cmbSpeed);
            this.groupBox2.Controls.Add(this.btnSpeed);
            this.groupBox2.Controls.Add(this.cmbExp);
            this.groupBox2.Controls.Add(this.btnResetCounter);
            this.groupBox2.Controls.Add(this.btnExp);
            this.groupBox2.Controls.Add(this.btnPump);
            this.groupBox2.Controls.Add(this.btnDir);
            this.groupBox2.Location = new System.Drawing.Point(13, 98);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(261, 230);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Управление";
            // 
            // lblHV
            // 
            this.lblHV.AutoSize = true;
            this.lblHV.Location = new System.Drawing.Point(8, 202);
            this.lblHV.Name = "lblHV";
            this.lblHV.Size = new System.Drawing.Size(115, 13);
            this.lblHV.TabIndex = 12;
            this.lblHV.Text = "Напряжение СБМ-20:";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(8, 178);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(83, 13);
            this.lblTime.TabIndex = 11;
            this.lblTime.Text = "Время работы:";
            // 
            // lblCounter
            // 
            this.lblCounter.AutoSize = true;
            this.lblCounter.Location = new System.Drawing.Point(6, 114);
            this.lblCounter.Name = "lblCounter";
            this.lblCounter.Size = new System.Drawing.Size(35, 13);
            this.lblCounter.TabIndex = 9;
            this.lblCounter.Text = "label3";
            // 
            // lblDir
            // 
            this.lblDir.AutoSize = true;
            this.lblDir.Location = new System.Drawing.Point(38, 53);
            this.lblDir.Name = "lblDir";
            this.lblDir.Size = new System.Drawing.Size(35, 13);
            this.lblDir.TabIndex = 10;
            this.lblDir.Text = "label2";
            // 
            // lblPump
            // 
            this.lblPump.AutoSize = true;
            this.lblPump.Location = new System.Drawing.Point(25, 24);
            this.lblPump.Name = "lblPump";
            this.lblPump.Size = new System.Drawing.Size(35, 13);
            this.lblPump.TabIndex = 9;
            this.lblPump.Text = "label1";
            // 
            // btnSpeed
            // 
            this.btnSpeed.Location = new System.Drawing.Point(169, 140);
            this.btnSpeed.Name = "btnSpeed";
            this.btnSpeed.Size = new System.Drawing.Size(86, 23);
            this.btnSpeed.TabIndex = 9;
            this.btnSpeed.Text = "Переключить";
            this.btnSpeed.UseVisualStyleBackColor = true;
            // 
            // btnResetCounter
            // 
            this.btnResetCounter.Location = new System.Drawing.Point(169, 109);
            this.btnResetCounter.Name = "btnResetCounter";
            this.btnResetCounter.Size = new System.Drawing.Size(86, 23);
            this.btnResetCounter.TabIndex = 9;
            this.btnResetCounter.Text = "Сброс";
            this.btnResetCounter.UseVisualStyleBackColor = true;
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(169, 82);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(86, 23);
            this.btnExp.TabIndex = 9;
            this.btnExp.Text = "Переключить";
            this.btnExp.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnRecordStop);
            this.groupBox3.Controls.Add(this.btnRecordStart);
            this.groupBox3.Location = new System.Drawing.Point(18, 334);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(256, 57);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Запись в csv";
            // 
            // btnRecordStop
            // 
            this.btnRecordStop.Location = new System.Drawing.Point(164, 19);
            this.btnRecordStop.Name = "btnRecordStop";
            this.btnRecordStop.Size = new System.Drawing.Size(86, 23);
            this.btnRecordStop.TabIndex = 1;
            this.btnRecordStop.Text = "Остановить";
            this.btnRecordStop.UseVisualStyleBackColor = true;
            // 
            // btnRecordStart
            // 
            this.btnRecordStart.Location = new System.Drawing.Point(13, 19);
            this.btnRecordStart.Name = "btnRecordStart";
            this.btnRecordStart.Size = new System.Drawing.Size(95, 23);
            this.btnRecordStart.TabIndex = 0;
            this.btnRecordStart.Text = "Начать запись";
            this.btnRecordStart.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(137, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "EXP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "SPD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(137, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "IMP";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 403);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Утилита управления v1.2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDir;
        private System.Windows.Forms.Button btnConection;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnPump;
        private System.Windows.Forms.ComboBox cmbCOM;
        private System.Windows.Forms.ComboBox cmbExp;
        private System.Windows.Forms.ComboBox cmbSpeed;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblCounter;
        private System.Windows.Forms.Label lblDir;
        private System.Windows.Forms.Label lblPump;
        private System.Windows.Forms.Button btnSpeed;
        private System.Windows.Forms.Button btnResetCounter;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnRecordStop;
        private System.Windows.Forms.Button btnRecordStart;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblHV;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

